# Database Tables (from migrations)

## 0001_01_01_000000_create_users_table.php
```php
        Schema::create('users', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('name');
            $table->string('email')->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password')->nullable();
            $table->rememberToken();
            $table->timestamps();
        Schema::create('password_reset_tokens', function (Blueprint $table) {
            $table->string('email')->primary();
            $table->string('token');
            $table->timestamp('created_at')->nullable();
        Schema::create('sessions', function (Blueprint $table) {
            $table->string('id')->primary();
            $table->foreignUuid('user_id')->nullable()->index();
            $table->string('ip_address', 45)->nullable();
            $table->text('user_agent')->nullable();
            $table->longText('payload');
            $table->integer('last_activity')->index();
```

## 0001_01_01_000001_create_cache_table.php
```php
        Schema::create('cache', function (Blueprint $table) {
            $table->string('key')->primary();
            $table->mediumText('value');
            $table->integer('expiration');
        Schema::create('cache_locks', function (Blueprint $table) {
            $table->string('key')->primary();
            $table->string('owner');
            $table->integer('expiration');
```

## 0001_01_01_000002_create_jobs_table.php
```php
        Schema::create('jobs', function (Blueprint $table) {
            $table->id();
            $table->string('queue')->index();
            $table->longText('payload');
            $table->unsignedTinyInteger('attempts');
            $table->unsignedInteger('reserved_at')->nullable();
            $table->unsignedInteger('available_at');
            $table->unsignedInteger('created_at');
        Schema::create('job_batches', function (Blueprint $table) {
            $table->string('id')->primary();
            $table->string('name');
            $table->integer('total_jobs');
            $table->integer('pending_jobs');
            $table->integer('failed_jobs');
            $table->longText('failed_job_ids');
            $table->mediumText('options')->nullable();
            $table->integer('cancelled_at')->nullable();
            $table->integer('created_at');
            $table->integer('finished_at')->nullable();
        Schema::create('failed_jobs', function (Blueprint $table) {
            $table->id();
            $table->string('uuid')->unique();
            $table->text('connection');
            $table->text('queue');
            $table->longText('payload');
            $table->longText('exception');
            $table->timestamp('failed_at')->useCurrent();
```

## 2017_07_06_000000_create_table_magic_links.php
```php
        Schema::create('magic_links', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('token', 255);
            $table->text('action');
            $table->unsignedTinyInteger('num_visits')->default(0);
            $table->unsignedTinyInteger('max_visits')->nullable();
            $table->timestamp('available_at')->nullable();
            $table->string('access_code')->nullable();
            $table->timestamps();
            $table->index('available_at');
            $table->index('max_visits');
```

## 2025_01_15_000001_add_reviews_and_ratings_to_day_news_posts_table.php
```php
                    $table->decimal('average_rating', 3, 2)->nullable()->after('view_count');
                    $table->unsignedInteger('total_reviews')->default(0)->after('average_rating');
                    $indexes = Schema::getConnection()->getDoctrineSchemaManager()->listTableIndexes('day_news_posts');
                        $table->index('average_rating');
            $table->dropIndex(['average_rating']);
            $table->dropColumn(['average_rating', 'total_reviews']);
```

## 2025_01_15_000002_add_day_news_activity_types.php
```php
```

## 2025_01_15_000003_create_article_comments_table.php
```php
        Schema::create('article_comments', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignId('article_id')->constrained('day_news_posts')->cascadeOnDelete();
            $table->foreignUuid('user_id')->constrained('users')->cascadeOnDelete();
            $table->uuid('parent_id')->nullable();
            $table->text('content');
            $table->boolean('is_active')->default(true);
            $table->boolean('is_pinned')->default(false);
            $table->unsignedInteger('reports_count')->default(0);
            $table->timestamps();
            $table->index(['article_id', 'parent_id', 'created_at']);
            $table->index(['user_id', 'created_at']);
            $table->index(['article_id', 'is_active', 'created_at']);
            $table->foreign('parent_id')->references('id')->on('article_comments')->onDelete('cascade');
        Schema::create('article_comment_likes', function (Blueprint $table) {
            $table->id();
            $table->uuid('comment_id')->constrained('article_comments')->cascadeOnDelete();
            $table->foreignUuid('user_id')->constrained('users')->cascadeOnDelete();
            $table->timestamps();
            $table->unique(['comment_id', 'user_id']);
            $table->index(['comment_id', 'created_at']);
```

## 2025_01_15_000004_create_tags_table.php
```php
        Schema::create('tags', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('name');
            $table->string('slug')->unique();
            $table->text('description')->nullable();
            $table->unsignedInteger('article_count')->default(0);
            $table->unsignedInteger('followers_count')->default(0);
            $table->boolean('is_trending')->default(false);
            $table->unsignedInteger('trending_score')->default(0);
            $table->timestamps();
            $table->index('slug');
            $table->index('is_trending');
            $table->index(['is_trending', 'trending_score']);
        Schema::create('day_news_post_tag', function (Blueprint $table) {
            $table->id();
            $table->foreignId('day_news_post_id')->constrained()->cascadeOnDelete();
            $table->uuid('tag_id')->constrained('tags')->cascadeOnDelete();
            $table->timestamps();
            $table->unique(['day_news_post_id', 'tag_id']);
            $table->index('tag_id');
```

## 2025_01_15_000005_create_search_tables.php
```php
        Schema::create('search_history', function (Blueprint $table) {
            $table->id();
            $table->foreignUuid('user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('query');
            $table->unsignedInteger('results_count')->default(0);
            $table->json('filters')->nullable();
            $table->string('ip_address')->nullable();
            $table->timestamps();
            $table->index(['user_id', 'created_at']);
            $table->index(['query', 'created_at']);
            $table->index('created_at');
        Schema::create('search_suggestions', function (Blueprint $table) {
            $table->id();
            $table->string('query')->unique();
            $table->unsignedInteger('popularity')->default(1);
            $table->unsignedInteger('click_count')->default(0);
            $table->timestamps();
            $table->index('popularity');
            $table->index('query');
```

## 2025_01_15_000006_create_comment_reports_table.php
```php
        Schema::create('comment_reports', function (Blueprint $table) {
            $table->id();
            $table->uuid('comment_id')->constrained('article_comments')->cascadeOnDelete();
            $table->foreignUuid('user_id')->constrained('users')->cascadeOnDelete();
            $table->string('reason'); // spam, harassment, inappropriate, other
            $table->text('details')->nullable();
            $table->enum('status', ['pending', 'reviewed', 'resolved', 'dismissed'])->default('pending');
            $table->timestamps();
            $table->unique(['comment_id', 'user_id']); // One report per user per comment
            $table->index(['status', 'created_at']);
            $table->index('comment_id');
```

## 2025_01_15_000007_create_announcements_table.php
```php
        Schema::create('announcements', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignUuid('workspace_id')->nullable()->constrained()->nullOnDelete();
            $table->enum('type', [
            $table->string('title');
            $table->text('content');
            $table->string('image')->nullable();
            $table->string('location')->nullable();
            $table->date('event_date')->nullable();
            $table->enum('status', ['draft', 'pending', 'published', 'expired', 'removed'])->default('draft');
            $table->timestamp('published_at')->nullable();
            $table->timestamp('expires_at')->nullable();
            $table->unsignedInteger('views_count')->default(0);
            $table->unsignedInteger('reactions_count')->default(0);
            $table->unsignedInteger('comments_count')->default(0);
            $table->timestamps();
            $table->index(['type', 'status']);
            $table->index(['status', 'published_at']);
            $table->index(['user_id', 'status']);
            $table->index('event_date');
        Schema::create('announcement_region', function (Blueprint $table) {
            $table->id();
            $table->uuid('announcement_id')->constrained('announcements')->cascadeOnDelete();
            $table->foreignUuid('region_id')->constrained()->cascadeOnDelete();
            $table->timestamps();
            $table->unique(['announcement_id', 'region_id']);
```

## 2025_01_15_000008_create_classifieds_tables.php
```php
        Schema::create('classifieds', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignUuid('workspace_id')->nullable()->constrained()->nullOnDelete();
            $table->enum('category', [
            $table->string('subcategory')->nullable();
            $table->string('title');
            $table->text('description');
            $table->decimal('price', 10, 2)->nullable();
            $table->string('price_type')->nullable(); // fixed, negotiable, contact_for_pricing
            $table->string('condition')->nullable(); // new, like_new, excellent, good, fair, poor
            $table->string('location');
            $table->boolean('is_featured')->default(false);
            $table->enum('status', ['draft', 'pending_payment', 'active', 'expired', 'sold', 'removed'])->default('draft');
            $table->timestamp('posted_at')->nullable();
            $table->timestamp('expires_at')->nullable();
            $table->unsignedInteger('views_count')->default(0);
            $table->timestamps();
            $table->index(['category', 'status']);
            $table->index(['status', 'posted_at']);
            $table->index(['user_id', 'status']);
            $table->index('expires_at');
        Schema::create('classified_images', function (Blueprint $table) {
            $table->id();
            $table->uuid('classified_id')->constrained('classifieds')->cascadeOnDelete();
            $table->string('image_path');
            $table->string('image_disk')->default('public');
            $table->unsignedInteger('order')->default(0);
            $table->timestamps();
            $table->index(['classified_id', 'order']);
```

## 2025_01_15_000009_create_coupons_table.php
```php
        Schema::create('coupons', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignUuid('business_id')->nullable()->constrained('businesses')->nullOnDelete();
            $table->string('title');
            $table->text('description')->nullable();
            $table->enum('discount_type', ['percentage', 'fixed_amount', 'buy_one_get_one', 'free_item'])->default('percentage');
            $table->decimal('discount_value', 10, 2)->nullable(); // Percentage or fixed amount
            $table->text('terms')->nullable();
            $table->string('code')->unique()->nullable(); // Optional coupon code
            $table->string('image')->nullable();
            $table->string('business_name');
            $table->string('business_location')->nullable();
            $table->date('start_date');
            $table->date('end_date');
            $table->unsignedInteger('usage_limit')->nullable(); // Max number of uses
            $table->unsignedInteger('used_count')->default(0);
            $table->enum('status', ['draft', 'active', 'expired', 'disabled'])->default('draft');
            $table->unsignedInteger('views_count')->default(0);
            $table->unsignedInteger('clicks_count')->default(0);
            $table->timestamps();
            $table->index(['status', 'start_date', 'end_date']);
            $table->index(['business_id', 'status']);
            $table->index('code');
            $table->index('end_date');
        Schema::create('coupon_region', function (Blueprint $table) {
            $table->id();
            $table->uuid('coupon_id')->constrained('coupons')->cascadeOnDelete();
            $table->foreignUuid('region_id')->constrained()->cascadeOnDelete();
            $table->timestamps();
```

## 2025_01_15_000010_create_photos_tables.php
```php
        Schema::create('photo_albums', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignUuid('workspace_id')->nullable()->constrained()->nullOnDelete();
            $table->string('title');
            $table->text('description')->nullable();
            $table->string('cover_image')->nullable();
            $table->enum('visibility', ['public', 'private', 'community'])->default('public');
            $table->unsignedInteger('photos_count')->default(0);
            $table->unsignedInteger('views_count')->default(0);
            $table->timestamps();
            $table->index(['user_id', 'visibility']);
            $table->index('created_at');
        Schema::create('photos', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('user_id')->constrained('users')->cascadeOnDelete();
            $table->uuid('album_id')->nullable()->constrained('photo_albums')->nullOnDelete();
            $table->string('title');
            $table->text('description')->nullable();
            $table->string('image_path');
            $table->string('image_disk')->default('public');
            $table->string('thumbnail_path')->nullable();
            $table->string('category')->nullable(); // Nature, Events, Recreation, Community, Sports, etc.
            $table->enum('status', ['pending', 'approved', 'rejected'])->default('pending');
            $table->unsignedInteger('width')->nullable();
            $table->unsignedInteger('height')->nullable();
            $table->unsignedBigInteger('file_size')->nullable(); // in bytes
            $table->unsignedInteger('views_count')->default(0);
            $table->unsignedInteger('likes_count')->default(0);
            $table->unsignedInteger('comments_count')->default(0);
```

## 2025_01_15_000011_add_author_fields_to_users_table.php
```php
            $table->text('bio')->nullable()->after('email');
            $table->string('author_slug')->nullable()->unique()->after('bio');
            $table->decimal('trust_score', 5, 2)->default(0.00)->after('author_slug');
            $table->enum('trust_tier', ['bronze', 'silver', 'gold', 'platinum'])->nullable()->after('trust_score');
            $table->boolean('is_verified_author')->default(false)->after('trust_tier');
            $table->json('author_metadata')->nullable()->after('is_verified_author');
            $table->dropColumn([
```

## 2025_01_15_000012_create_legal_notices_table.php
```php
        Schema::create('legal_notices', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignUuid('workspace_id')->nullable()->constrained()->nullOnDelete();
            $table->enum('type', [
            $table->string('case_number')->nullable();
            $table->string('title');
            $table->text('content');
            $table->string('court')->nullable();
            $table->date('publish_date');
            $table->date('expiry_date')->nullable();
            $table->enum('status', ['active', 'expires_soon', 'expired', 'removed'])->default('active');
            $table->json('metadata')->nullable(); // Store additional case-specific data
            $table->unsignedInteger('views_count')->default(0);
            $table->timestamps();
            $table->index(['type', 'status']);
            $table->index(['status', 'publish_date']);
            $table->index(['publish_date', 'expiry_date']);
            $table->index('case_number');
        Schema::create('legal_notice_region', function (Blueprint $table) {
            $table->id();
            $table->uuid('legal_notice_id')->constrained('legal_notices')->cascadeOnDelete();
            $table->foreignUuid('region_id')->constrained()->cascadeOnDelete();
            $table->timestamps();
            $table->unique(['legal_notice_id', 'region_id']);
```

## 2025_01_15_000013_create_memorials_table.php
```php
        Schema::create('memorials', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignUuid('workspace_id')->nullable()->constrained()->nullOnDelete();
            $table->string('name');
            $table->string('years'); // e.g., "1932 - 2023"
            $table->date('date_of_passing');
            $table->text('obituary');
            $table->string('image')->nullable();
            $table->string('location')->nullable();
            $table->date('service_date')->nullable();
            $table->string('service_location')->nullable();
            $table->text('service_details')->nullable();
            $table->boolean('is_featured')->default(false);
            $table->enum('status', ['draft', 'published', 'removed'])->default('draft');
            $table->timestamp('published_at')->nullable();
            $table->unsignedInteger('views_count')->default(0);
            $table->unsignedInteger('reactions_count')->default(0);
            $table->unsignedInteger('comments_count')->default(0);
            $table->timestamps();
            $table->index(['status', 'published_at']);
            $table->index(['date_of_passing', 'status']);
            $table->index('is_featured');
        Schema::create('memorial_region', function (Blueprint $table) {
            $table->id();
            $table->uuid('memorial_id')->constrained('memorials')->cascadeOnDelete();
            $table->foreignUuid('region_id')->constrained()->cascadeOnDelete();
            $table->timestamps();
            $table->unique(['memorial_id', 'region_id']);
```

## 2025_01_15_000014_create_podcasts_tables.php
```php
        Schema::create('creator_profiles', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('user_id')->constrained('users')->cascadeOnDelete();
            $table->string('display_name');
            $table->string('slug')->unique();
            $table->text('bio')->nullable();
            $table->string('avatar')->nullable();
            $table->string('cover_image')->nullable();
            $table->json('social_links')->nullable(); // Twitter, Instagram, etc.
            $table->enum('status', ['pending', 'approved', 'rejected', 'suspended'])->default('pending');
            $table->unsignedInteger('followers_count')->default(0);
            $table->unsignedInteger('podcasts_count')->default(0);
            $table->unsignedInteger('episodes_count')->default(0);
            $table->unsignedInteger('total_listens')->default(0);
            $table->timestamps();
            $table->index(['status', 'created_at']);
            $table->index('slug');
        Schema::create('podcasts', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('creator_profile_id')->constrained('creator_profiles')->cascadeOnDelete();
            $table->string('title');
            $table->string('slug')->unique();
            $table->text('description')->nullable();
            $table->string('cover_image')->nullable();
            $table->string('category')->nullable();
            $table->enum('status', ['draft', 'published', 'archived'])->default('draft');
            $table->timestamp('published_at')->nullable();
            $table->unsignedInteger('episodes_count')->default(0);
            $table->unsignedInteger('subscribers_count')->default(0);
            $table->unsignedInteger('total_listens')->default(0);
```

## 2025_05_03_144545_create_social_accounts_table.php
```php
        Schema::create('social_accounts', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('user_id')->constrained('users', 'id')->onDelete('cascade');
            $table->string('provider');
            $table->string('provider_id')->unique();
            $table->string('name')->nullable();
            $table->longText('token')->nullable();
            $table->longText('refresh_token')->nullable();
            $table->longText('avatar')->nullable();
            $table->longText('code')->nullable();
            $table->timestamp('expires_at')->nullable();
            $table->timestamps();
            $table->index(['provider', 'user_id', 'provider_id', 'expires_at']);
```

## 2025_05_03_154707_create_workspaces_table.php
```php
        Schema::create('workspaces', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('owner_id')->constrained('users', 'id');
            $table->string('name');
            $table->string('slug')->unique();
            $table->longText('logo')->nullable();
            $table->string('timezone')->default('UTC');
            $table->string('stripe_connect_id')->nullable()->unique();
            $table->boolean('stripe_charges_enabled')->default(false);
            $table->boolean('stripe_payouts_enabled')->default(false);
            $table->boolean('stripe_admin_approved')->default(false);
            $table->timestamps();
            $table->index(['owner_id']);
            $table->foreignUuid('current_workspace_id')->nullable()->constrained('workspaces');
        Schema::create('roles', function (Blueprint $table) {
            $table->text('name')->primary();
            $table->timestamps();
        Schema::create('workspace_memberships', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('workspace_id')->constrained('workspaces');
            $table->foreignUuid('user_id')->constrained('users');
            $table->text('role');
            $table->foreign('role')->references('name')->on('roles');
            $table->timestamps();
            $table->index(['workspace_id', 'user_id', 'role']);
            $table->dropConstrainedForeignId('current_workspace_id');
```

## 2025_05_07_230832_create_default_roles.php
```php
        DB::table('roles')->insert([
        DB::table('roles')->whereIn('name', ['owner', 'admin', 'member'])->delete();
```

## 2025_07_16_171440_create_workspace_invitations_table.php
```php
        Schema::create('workspace_invitations', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('workspace_id')->constrained('workspaces')->cascadeOnDelete();
            $table->foreignUuid('invited_by')->nullable()->constrained('users', 'id')->nullOnDelete();
            $table->string('email');
            $table->string('role');
            $table->string('token')->unique();
            $table->timestamp('expires_at');
            $table->timestamp('accepted_at')->nullable();
            $table->timestamps();
            $table->foreign('role')->references('name')->on('roles');
            $table->index(['email', 'workspace_id']);
            $table->index(['token']);
```

## 2025_08_22_192832_create_credits_table.php
```php
        Schema::create('credits', function (Blueprint $table) {
            $table->id();
            $table->uuidMorphs('creditable');
            $table->decimal('amount', 10, 2);
            $table->decimal('running_balance', 10, 2);
            $table->string('description', 255)->nullable();
            $table->string('type');
            $table->json('metadata')->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->index('type');
            $table->index('created_at');
            $table->index(['creditable_id', 'creditable_type', 'created_at']);
            $table->index(['creditable_id', 'creditable_type', 'running_balance']);
            $table->index(['creditable_id', 'creditable_type', 'deleted_at']);
```

## 2025_09_15_160356_create_venues_table.php
```php
        Schema::create('venues', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('name');
            $table->text('description');
            $table->json('images')->nullable(); // Array of image URLs
            $table->boolean('verified')->default(false);
            $table->string('venue_type');
            $table->integer('capacity');
            $table->decimal('price_per_hour', 10, 2);
            $table->decimal('price_per_event', 10, 2);
            $table->decimal('price_per_day', 10, 2);
            $table->decimal('average_rating', 3, 2)->default(0);
            $table->integer('total_reviews')->default(0);
            $table->string('address');
            $table->string('neighborhood')->nullable();
            $table->decimal('latitude', 10, 8)->nullable();
            $table->decimal('longitude', 11, 8)->nullable();
            $table->string('google_place_id')->nullable()->index();
            $table->string('postal_code')->nullable();
            $table->json('amenities')->nullable(); // Array of amenities
            $table->json('event_types')->nullable(); // Array of supported event types
            $table->json('unavailable_dates')->nullable(); // Array of unavailable dates
            $table->integer('last_booked_days_ago')->nullable();
            $table->integer('response_time_hours')->default(24);
            $table->date('listed_date')->nullable();
            $table->enum('status', ['active', 'inactive', 'pending', 'suspended'])->default('active');
            $table->foreignUuid('workspace_id')->constrained('workspaces')->onDelete('cascade');
            $table->foreignUuid('created_by')->nullable()->constrained('users')->onDelete('set null');
            $table->timestamps();
            $table->index(['venue_type', 'status']);
```

## 2025_09_15_160414_create_performers_table.php
```php
        Schema::create('performers', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('name');
            $table->string('profile_image')->nullable();
            $table->json('genres'); // Array of genres
            $table->decimal('average_rating', 3, 2)->default(0);
            $table->integer('total_reviews')->default(0);
            $table->integer('follower_count')->default(0);
            $table->text('bio')->nullable();
            $table->integer('years_active')->default(0);
            $table->integer('shows_played')->default(0);
            $table->string('home_city');
            $table->boolean('is_verified')->default(false);
            $table->boolean('is_touring_now')->default(false);
            $table->boolean('available_for_booking')->default(true);
            $table->boolean('has_merchandise')->default(false);
            $table->boolean('has_original_music')->default(false);
            $table->boolean('offers_meet_and_greet')->default(false);
            $table->boolean('takes_requests')->default(false);
            $table->boolean('available_for_private_events')->default(true);
            $table->boolean('is_family_friendly')->default(true);
            $table->boolean('has_samples')->default(false);
            $table->integer('trending_score')->default(0);
            $table->decimal('distance_miles', 8, 2)->nullable();
            $table->date('added_date')->nullable();
            $table->boolean('introductory_pricing')->default(false);
            $table->decimal('base_price', 10, 2)->nullable();
            $table->string('currency', 3)->default('USD');
            $table->integer('minimum_booking_hours')->default(1);
            $table->decimal('travel_fee_per_mile', 8, 2)->nullable();
```

## 2025_09_15_160428_create_events_table.php
```php
        Schema::create('events', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('title');
            $table->string('image')->nullable();
            $table->dateTime('event_date');
            $table->string('time');
            $table->text('description');
            $table->json('badges')->nullable(); // Array of badges
            $table->json('subcategories')->nullable(); // Array of subcategories
            $table->string('category')->nullable();
            $table->boolean('is_free')->default(false);
            $table->decimal('price_min', 10, 2)->default(0);
            $table->decimal('price_max', 10, 2)->default(0);
            $table->decimal('community_rating', 3, 2)->default(0);
            $table->integer('member_attendance')->default(0);
            $table->integer('member_recommendations')->default(0);
            $table->string('discussion_thread_id')->nullable();
            $table->text('curator_notes')->nullable();
            $table->decimal('latitude', 10, 8)->nullable();
            $table->decimal('longitude', 11, 8)->nullable();
            $table->string('google_place_id')->nullable()->index();
            $table->string('postal_code')->nullable();
            $table->foreignUuid('venue_id')->nullable()->constrained('venues')->onDelete('set null');
            $table->foreignUuid('performer_id')->nullable()->constrained('performers')->onDelete('set null');
            $table->foreignUuid('workspace_id')->constrained('workspaces')->onDelete('cascade');
            $table->foreignUuid('created_by')->nullable()->constrained('users')->onDelete('set null'); // Event creator
            $table->enum('status', ['draft', 'published', 'cancelled', 'completed'])->default('draft');
            $table->timestamps();
            $table->index(['status', 'event_date']);
            $table->index(['venue_id', 'event_date']);
```

## 2025_09_15_160437_create_bookings_table.php
```php
        Schema::create('bookings', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('booking_number')->unique();
            $table->enum('status', ['pending', 'confirmed', 'cancelled', 'completed', 'rejected', 'refunded'])->default('pending');
            $table->enum('booking_type', ['event', 'venue', 'performer']);
            $table->foreignUuid('event_id')->nullable()->constrained('events')->onDelete('cascade');
            $table->foreignUuid('venue_id')->nullable()->constrained('venues')->onDelete('cascade');
            $table->foreignUuid('performer_id')->nullable()->constrained('performers')->onDelete('cascade');
            $table->foreignUuid('workspace_id')->constrained('workspaces')->onDelete('cascade');
            $table->foreignUuid('created_by')->nullable()->constrained('users')->onDelete('set null');
            $table->string('contact_name');
            $table->string('contact_email');
            $table->string('contact_phone')->nullable();
            $table->string('contact_company')->nullable();
            $table->date('event_date')->nullable();
            $table->time('start_time')->nullable();
            $table->time('end_time')->nullable();
            $table->string('event_type')->nullable();
            $table->integer('expected_guests')->nullable();
            $table->integer('expected_audience')->nullable(); // For performer bookings
            $table->integer('ticket_quantity')->nullable();
            $table->string('ticket_type')->nullable();
            $table->decimal('price_per_ticket', 10, 2)->nullable();
            $table->enum('payment_status', ['pending', 'paid', 'partially_paid', 'failed', 'refunded', 'cancelled'])->default('pending');
            $table->decimal('total_amount', 10, 2);
            $table->string('currency', 3)->default('USD');
            $table->decimal('paid_amount', 10, 2)->default(0);
            $table->string('payment_method')->nullable();
            $table->string('transaction_id')->nullable();
            $table->timestamp('payment_date')->nullable();
```

## 2025_09_15_160601_create_upcoming_shows_table.php
```php
        Schema::create('upcoming_shows', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('performer_id')->constrained('performers')->onDelete('cascade');
            $table->date('date');
            $table->string('venue');
            $table->boolean('tickets_available')->default(true);
            $table->string('ticket_url')->nullable();
            $table->decimal('ticket_price', 10, 2)->nullable();
            $table->text('description')->nullable();
            $table->timestamps();
            $table->index(['performer_id', 'date']);
            $table->index('date');
```

## 2025_09_15_163335_create_reviews_table.php
```php
        Schema::create('reviews', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuidMorphs('reviewable'); // reviewable_type, reviewable_id
            $table->foreignUuid('user_id')->constrained('users')->onDelete('cascade');
            $table->string('title');
            $table->text('content');
            $table->integer('rating')->unsigned(); // 1-5 stars
            $table->boolean('is_verified')->default(false);
            $table->boolean('is_featured')->default(false);
            $table->json('helpful_votes')->nullable(); // Array of user IDs who found it helpful
            $table->integer('helpful_count')->default(0);
            $table->enum('status', ['pending', 'approved', 'rejected', 'hidden'])->default('pending');
            $table->timestamp('approved_at')->nullable();
            $table->foreignUuid('approved_by')->nullable()->constrained('users')->onDelete('set null');
            $table->string('rejection_reason')->nullable();
            $table->timestamps();
            $table->index(['reviewable_type', 'reviewable_id'], 'reviews_reviewable_idx');
            $table->index(['user_id', 'reviewable_type', 'reviewable_id'], 'reviews_user_reviewable_idx');
            $table->index(['rating', 'status'], 'reviews_rating_status_idx');
            $table->index('status', 'reviews_status_idx');
            $table->unique(['user_id', 'reviewable_type', 'reviewable_id'], 'unique_user_review');
```

## 2025_09_15_163344_create_ratings_table.php
```php
        Schema::create('ratings', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuidMorphs('ratable'); // ratable_type, ratable_id
            $table->foreignUuid('user_id')->constrained('users')->onDelete('cascade');
            $table->integer('rating')->unsigned(); // 1-5 stars
            $table->string('context')->nullable(); // e.g., 'service', 'quality', 'value', 'overall'
            $table->text('notes')->nullable(); // Brief notes
            $table->enum('type', ['booking', 'general', 'event_attendance'])->default('general');
            $table->foreignUuid('booking_id')->nullable()->constrained('bookings')->onDelete('cascade');
            $table->timestamps();
            $table->index(['ratable_type', 'ratable_id'], 'ratings_ratable_idx');
            $table->index(['user_id', 'ratable_type', 'ratable_id'], 'ratings_user_ratable_idx');
            $table->index(['rating', 'type'], 'ratings_rating_type_idx');
            $table->index('context', 'ratings_context_idx');
            $table->unique(['user_id', 'ratable_type', 'ratable_id', 'context'], 'unique_user_rating');
```

## 2025_09_18_153847_create_community_system_tables.php
```php
        Schema::create('communities', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('slug')->unique();
            $table->string('name');
            $table->text('description');
            $table->string('image')->nullable();
            $table->json('categories')->nullable();
            $table->json('thread_types')->nullable();
            $table->json('popular_tags')->nullable();
            $table->text('guidelines')->nullable();
            $table->boolean('is_featured')->default(false);
            $table->integer('total_events')->default(0);
            $table->integer('active_today')->default(0);
            $table->timestamp('last_activity')->nullable();
            $table->boolean('is_active')->default(true);
            $table->foreignUuid('workspace_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('created_by')->constrained('users')->cascadeOnDelete();
            $table->timestamps();
        Schema::create('community_threads', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('title');
            $table->text('content');
            $table->text('preview')->nullable();
            $table->string('type'); // Discussion, Question, Announcement, Resource, Event
            $table->json('tags')->nullable();
            $table->json('images')->nullable();
            $table->boolean('is_pinned')->default(false);
            $table->boolean('is_locked')->default(false);
            $table->boolean('is_featured')->default(false);
            $table->timestamp('last_reply_at')->nullable();
```

## 2025_09_23_191514_create_social_features_tables.php
```php
        Schema::create('social_posts', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('user_id')->constrained()->cascadeOnDelete();
            $table->text('content');
            $table->json('media')->nullable(); // Store image/video URLs
            $table->enum('visibility', ['public', 'friends', 'private'])->default('public');
            $table->json('location')->nullable(); // Store location data
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            $table->index(['user_id', 'created_at']);
            $table->index(['visibility', 'is_active', 'created_at']);
        Schema::create('social_post_likes', function (Blueprint $table) {
            $table->id();
            $table->foreignUuid('post_id')->constrained('social_posts')->cascadeOnDelete();
            $table->foreignUuid('user_id')->constrained('users')->cascadeOnDelete();
            $table->timestamps();
            $table->unique(['post_id', 'user_id']);
            $table->index(['post_id', 'created_at']);
        Schema::create('social_post_comments', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('post_id')->constrained('social_posts')->cascadeOnDelete();
            $table->foreignUuid('user_id')->constrained('users')->cascadeOnDelete();
            $table->uuid('parent_id')->nullable();
            $table->text('content');
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            $table->index(['post_id', 'parent_id', 'created_at']);
            $table->index(['user_id', 'created_at']);
            $table->foreign('parent_id')->references('id')->on('social_post_comments')->onDelete('cascade');
        Schema::create('social_comment_likes', function (Blueprint $table) {
```

## 2025_09_25_124919_create_notifications_table.php
```php
        Schema::create('notifications', function (Blueprint $table) {
            $table->id();
            $table->uuid('user_id');
            $table->string('type');
            $table->json('data');
            $table->boolean('read')->default(false);
            $table->string('title');
            $table->text('message');
            $table->string('action_url')->nullable();
            $table->timestamps();
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            $table->index(['user_id', 'read']);
            $table->index('created_at');
```

## 2025_09_25_135743_create_messaging_system.php
```php
        Schema::create('conversations', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('type')->default('private'); // private, group
            $table->string('title')->nullable(); // For group conversations
            $table->json('metadata')->nullable(); // For additional conversation data
            $table->timestamp('last_message_at')->nullable();
            $table->timestamps();
            $table->index(['type', 'last_message_at']);
        Schema::create('conversation_participants', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('conversation_id');
            $table->uuid('user_id');
            $table->timestamp('joined_at');
            $table->timestamp('last_read_at')->nullable();
            $table->boolean('is_admin')->default(false);
            $table->timestamps();
            $table->foreign('conversation_id')->references('id')->on('conversations')->onDelete('cascade');
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            $table->unique(['conversation_id', 'user_id']);
            $table->index(['user_id', 'last_read_at']);
        Schema::create('messages', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('conversation_id');
            $table->uuid('sender_id');
            $table->text('content');
            $table->string('type')->default('text'); // text, image, file, system
            $table->json('metadata')->nullable(); // For file attachments, system message data, etc.
            $table->timestamp('edited_at')->nullable();
            $table->timestamps();
            $table->foreign('conversation_id')->references('id')->on('conversations')->onDelete('cascade');
```

## 2025_09_26_222707_create_ticket_system_tables.php
```php
        Schema::create('ticket_plans', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('event_id');
            $table->string('name');
            $table->text('description')->nullable();
            $table->decimal('price', 10, 2);
            $table->integer('max_quantity');
            $table->integer('available_quantity');
            $table->boolean('is_active')->default(true);
            $table->json('metadata')->nullable();
            $table->integer('sort_order')->default(0);
            $table->timestamps();
            $table->foreign('event_id')->references('id')->on('events')->onDelete('cascade');
            $table->index(['event_id', 'is_active']);
        Schema::create('ticket_orders', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('event_id');
            $table->uuid('user_id');
            $table->string('status')->default('pending');
            $table->decimal('subtotal', 10, 2);
            $table->decimal('fees', 10, 2)->default(0);
            $table->decimal('discount', 10, 2)->default(0);
            $table->decimal('total', 10, 2);
            $table->json('promo_code')->nullable();
            $table->json('billing_info')->nullable();
            $table->string('payment_intent_id')->nullable();
            $table->string('payment_status')->default('pending');
            $table->timestamp('completed_at')->nullable();
            $table->timestamps();
            $table->foreign('event_id')->references('id')->on('events')->onDelete('cascade');
```

## 2025_09_30_144841_create_follows_table.php
```php
        Schema::create('follows', function (Blueprint $table) {
            $table->id();
            $table->foreignUuid('user_id')->constrained()->cascadeOnDelete();
            $table->uuidMorphs('followable');
            $table->timestamps();
            $table->unique(['user_id', 'followable_type', 'followable_id']);
```

## 2025_10_02_175440_create_stores_table.php
```php
        Schema::create('stores', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('workspace_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->string('slug')->unique();
            $table->text('description')->nullable();
            $table->string('logo')->nullable();
            $table->string('banner')->nullable();
            $table->string('status')->default('pending'); // pending, approved, rejected, suspended
            $table->text('rejection_reason')->nullable();
            $table->timestamp('approved_at')->nullable();
            $table->timestamps();
            $table->softDeletes();
        Schema::create('products', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('store_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->string('slug');
            $table->text('description')->nullable();
            $table->json('images')->nullable();
            $table->decimal('price', 10, 2);
            $table->decimal('compare_at_price', 10, 2)->nullable();
            $table->integer('quantity')->default(0);
            $table->boolean('track_inventory')->default(true);
            $table->string('sku')->nullable();
            $table->boolean('is_active')->default(true);
            $table->boolean('is_featured')->default(false);
            $table->string('stripe_price_id')->nullable();
            $table->string('stripe_product_id')->nullable();
            $table->json('metadata')->nullable();
```

## 2025_10_02_211800_create_carts_table.php
```php
        Schema::create('carts', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('user_id')->nullable()->constrained()->cascadeOnDelete();
            $table->string('session_id')->nullable()->index();
            $table->timestamps();
            $table->index(['user_id', 'session_id']);
        Schema::create('cart_items', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('cart_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('product_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('store_id')->constrained()->cascadeOnDelete();
            $table->integer('quantity')->default(1);
            $table->decimal('price', 10, 2);
            $table->timestamps();
            $table->unique(['cart_id', 'product_id']);
```

## 2025_10_06_143426_create_calendars_table.php
```php
        Schema::create('calendars', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('user_id')->constrained()->cascadeOnDelete();
            $table->string('title');
            $table->text('description');
            $table->string('category');
            $table->string('image')->nullable();
            $table->text('about')->nullable();
            $table->string('location')->nullable();
            $table->string('update_frequency')->default('weekly');
            $table->decimal('subscription_price', 10, 2)->default(0);
            $table->boolean('is_private')->default(false);
            $table->boolean('is_verified')->default(false);
            $table->integer('followers_count')->default(0);
            $table->integer('events_count')->default(0);
            $table->timestamps();
        Schema::create('calendar_followers', function (Blueprint $table) {
            $table->id();
            $table->foreignUuid('calendar_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('user_id')->constrained()->cascadeOnDelete();
            $table->timestamps();
            $table->unique(['calendar_id', 'user_id']);
        Schema::create('calendar_roles', function (Blueprint $table) {
            $table->id();
            $table->foreignUuid('calendar_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('user_id')->constrained()->cascadeOnDelete();
            $table->string('role')->default('editor');
            $table->timestamps();
            $table->unique(['calendar_id', 'user_id']);
        Schema::create('calendar_events', function (Blueprint $table) {
```

## 2025_10_28_134749_create_region_news_system_tables.php
```php
        Schema::create('regions', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('name');
            $table->string('slug')->unique();
            $table->enum('type', ['state', 'county', 'city', 'neighborhood']);
            $table->uuid('parent_id')->nullable();
            $table->text('description')->nullable();
            $table->boolean('is_active')->default(true);
            $table->integer('display_order')->default(0);
            $table->json('metadata')->nullable();
            $table->decimal('latitude', 10, 7)->nullable();
            $table->decimal('longitude', 10, 7)->nullable();
            $table->timestamps();
            $table->index('slug');
            $table->index('type');
            $table->index('parent_id');
            $table->index('is_active');
            $table->index(['latitude', 'longitude']);
            $table->foreign('parent_id')
                ->references('id')
                ->on('regions')
                ->onDelete('cascade');
        Schema::create('region_zipcodes', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('region_id')->constrained('regions')->onDelete('cascade');
            $table->string('zipcode', 10);
            $table->boolean('is_primary')->default(false);
            $table->timestamps();
            $table->unique(['region_id', 'zipcode']);
            $table->index('zipcode');
```

## 2025_11_04_210900_create_day_news_tables.php
```php
        Schema::create('day_news_posts', function (Blueprint $table) {
            $table->id();
            $table->foreignUuid('workspace_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('author_id')->nullable()->constrained('users')->nullOnDelete();
            $table->enum('type', ['article', 'announcement', 'notice', 'ad', 'schedule']);
            $table->enum('category', [
            ])->nullable();
            $table->string('title');
            $table->string('slug')->unique();
            $table->text('content');
            $table->text('excerpt')->nullable();
            $table->string('featured_image')->nullable();
            $table->json('metadata')->nullable();
            $table->enum('status', ['draft', 'published', 'expired', 'removed'])->default('draft');
            $table->timestamp('published_at')->nullable();
            $table->timestamp('expires_at')->nullable();
            $table->unsignedBigInteger('view_count')->default(0);
            $table->timestamps();
            $table->index(['workspace_id', 'status']);
            $table->index(['type', 'status']);
            $table->index(['published_at', 'status']);
            $table->index('slug');
        Schema::create('day_news_post_payments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('post_id')->constrained('day_news_posts')->cascadeOnDelete();
            $table->foreignUuid('workspace_id')->constrained()->cascadeOnDelete();
            $table->string('stripe_payment_intent_id')->nullable();
            $table->string('stripe_checkout_session_id')->nullable();
            $table->integer('amount');
            $table->string('currency', 3)->default('usd');
```

## 2025_11_04_210901_add_reviews_and_ratings_to_day_news_posts_table.php
```php
            $table->decimal('average_rating', 3, 2)->nullable()->after('view_count');
            $table->unsignedInteger('total_reviews')->default(0)->after('average_rating');
            $table->index('average_rating');
            $table->dropIndex(['average_rating']);
            $table->dropColumn(['average_rating', 'total_reviews']);
```

## 2025_11_04_210902_add_day_news_activity_types.php
```php
```

## 2025_11_04_210903_create_article_comments_table.php
```php
        Schema::create('article_comments', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignId('article_id')->constrained('day_news_posts')->cascadeOnDelete();
            $table->foreignUuid('user_id')->constrained('users')->cascadeOnDelete();
            $table->uuid('parent_id')->nullable();
            $table->text('content');
            $table->boolean('is_active')->default(true);
            $table->boolean('is_pinned')->default(false);
            $table->unsignedInteger('reports_count')->default(0);
            $table->timestamps();
            $table->index(['article_id', 'parent_id', 'created_at']);
            $table->index(['user_id', 'created_at']);
            $table->index(['article_id', 'is_active', 'created_at']);
            $table->foreign('parent_id')->references('id')->on('article_comments')->onDelete('cascade');
        Schema::create('article_comment_likes', function (Blueprint $table) {
            $table->id();
            $table->uuid('comment_id')->constrained('article_comments')->cascadeOnDelete();
            $table->foreignUuid('user_id')->constrained('users')->cascadeOnDelete();
            $table->timestamps();
            $table->unique(['comment_id', 'user_id']);
            $table->index(['comment_id', 'created_at']);
```

## 2025_11_04_210904_create_tags_table.php
```php
        Schema::create('tags', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('name');
            $table->string('slug')->unique();
            $table->text('description')->nullable();
            $table->unsignedInteger('article_count')->default(0);
            $table->unsignedInteger('followers_count')->default(0);
            $table->boolean('is_trending')->default(false);
            $table->unsignedInteger('trending_score')->default(0);
            $table->timestamps();
            $table->index('slug');
            $table->index('is_trending');
            $table->index(['is_trending', 'trending_score']);
        Schema::create('day_news_post_tag', function (Blueprint $table) {
            $table->id();
            $table->foreignId('day_news_post_id')->constrained()->cascadeOnDelete();
            $table->uuid('tag_id')->constrained('tags')->cascadeOnDelete();
            $table->timestamps();
            $table->unique(['day_news_post_id', 'tag_id']);
            $table->index('tag_id');
```

## 2025_11_04_210905_create_search_tables.php
```php
        Schema::create('search_history', function (Blueprint $table) {
            $table->id();
            $table->foreignUuid('user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('query');
            $table->unsignedInteger('results_count')->default(0);
            $table->json('filters')->nullable();
            $table->string('ip_address')->nullable();
            $table->timestamps();
            $table->index(['user_id', 'created_at']);
            $table->index(['query', 'created_at']);
            $table->index('created_at');
        Schema::create('search_suggestions', function (Blueprint $table) {
            $table->id();
            $table->string('query')->unique();
            $table->unsignedInteger('popularity')->default(1);
            $table->unsignedInteger('click_count')->default(0);
            $table->timestamps();
            $table->index('popularity');
            $table->index('query');
```

## 2025_11_04_210906_create_comment_reports_table.php
```php
        Schema::create('comment_reports', function (Blueprint $table) {
            $table->id();
            $table->uuid('comment_id')->constrained('article_comments')->cascadeOnDelete();
            $table->foreignUuid('user_id')->constrained('users')->cascadeOnDelete();
            $table->string('reason'); // spam, harassment, inappropriate, other
            $table->text('details')->nullable();
            $table->enum('status', ['pending', 'reviewed', 'resolved', 'dismissed'])->default('pending');
            $table->timestamps();
            $table->unique(['comment_id', 'user_id']); // One report per user per comment
            $table->index(['status', 'created_at']);
            $table->index('comment_id');
```

## 2025_11_04_210907_create_announcements_table.php
```php
        Schema::create('announcements', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignUuid('workspace_id')->nullable()->constrained()->nullOnDelete();
            $table->enum('type', [
            $table->string('title');
            $table->text('content');
            $table->string('image')->nullable();
            $table->string('location')->nullable();
            $table->date('event_date')->nullable();
            $table->enum('status', ['draft', 'pending', 'published', 'expired', 'removed'])->default('draft');
            $table->timestamp('published_at')->nullable();
            $table->timestamp('expires_at')->nullable();
            $table->unsignedInteger('views_count')->default(0);
            $table->unsignedInteger('reactions_count')->default(0);
            $table->unsignedInteger('comments_count')->default(0);
            $table->timestamps();
            $table->index(['type', 'status']);
            $table->index(['status', 'published_at']);
            $table->index(['user_id', 'status']);
            $table->index('event_date');
        Schema::create('announcement_region', function (Blueprint $table) {
            $table->id();
            $table->uuid('announcement_id')->constrained('announcements')->cascadeOnDelete();
            $table->foreignUuid('region_id')->constrained()->cascadeOnDelete();
            $table->timestamps();
            $table->unique(['announcement_id', 'region_id']);
```

## 2025_11_04_210908_create_classifieds_tables.php
```php
        Schema::create('classifieds', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignUuid('workspace_id')->nullable()->constrained()->nullOnDelete();
            $table->enum('category', [
            $table->string('subcategory')->nullable();
            $table->string('title');
            $table->text('description');
            $table->decimal('price', 10, 2)->nullable();
            $table->string('price_type')->nullable(); // fixed, negotiable, contact_for_pricing
            $table->string('condition')->nullable(); // new, like_new, excellent, good, fair, poor
            $table->string('location');
            $table->boolean('is_featured')->default(false);
            $table->enum('status', ['draft', 'pending_payment', 'active', 'expired', 'sold', 'removed'])->default('draft');
            $table->timestamp('posted_at')->nullable();
            $table->timestamp('expires_at')->nullable();
            $table->unsignedInteger('views_count')->default(0);
            $table->timestamps();
            $table->index(['category', 'status']);
            $table->index(['status', 'posted_at']);
            $table->index(['user_id', 'status']);
            $table->index('expires_at');
        Schema::create('classified_images', function (Blueprint $table) {
            $table->id();
            $table->uuid('classified_id')->constrained('classifieds')->cascadeOnDelete();
            $table->string('image_path');
            $table->string('image_disk')->default('public');
            $table->unsignedInteger('order')->default(0);
            $table->timestamps();
            $table->index(['classified_id', 'order']);
```

## 2025_11_04_210909_create_coupons_table.php
```php
        Schema::create('coupons', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignUuid('business_id')->nullable()->constrained('businesses')->nullOnDelete();
            $table->string('title');
            $table->text('description')->nullable();
            $table->enum('discount_type', ['percentage', 'fixed_amount', 'buy_one_get_one', 'free_item'])->default('percentage');
            $table->decimal('discount_value', 10, 2)->nullable(); // Percentage or fixed amount
            $table->text('terms')->nullable();
            $table->string('code')->unique()->nullable(); // Optional coupon code
            $table->string('image')->nullable();
            $table->string('business_name');
            $table->string('business_location')->nullable();
            $table->date('start_date');
            $table->date('end_date');
            $table->unsignedInteger('usage_limit')->nullable(); // Max number of uses
            $table->unsignedInteger('used_count')->default(0);
            $table->enum('status', ['draft', 'active', 'expired', 'disabled'])->default('draft');
            $table->unsignedInteger('views_count')->default(0);
            $table->unsignedInteger('clicks_count')->default(0);
            $table->timestamps();
            $table->index(['status', 'start_date', 'end_date']);
            $table->index(['business_id', 'status']);
            $table->index('code');
            $table->index('end_date');
        Schema::create('coupon_region', function (Blueprint $table) {
            $table->id();
            $table->uuid('coupon_id')->constrained('coupons')->cascadeOnDelete();
            $table->foreignUuid('region_id')->constrained()->cascadeOnDelete();
            $table->timestamps();
```

## 2025_11_04_210910_create_photos_tables.php
```php
        Schema::create('photo_albums', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignUuid('workspace_id')->nullable()->constrained()->nullOnDelete();
            $table->string('title');
            $table->text('description')->nullable();
            $table->string('cover_image')->nullable();
            $table->enum('visibility', ['public', 'private', 'community'])->default('public');
            $table->unsignedInteger('photos_count')->default(0);
            $table->unsignedInteger('views_count')->default(0);
            $table->timestamps();
            $table->index(['user_id', 'visibility']);
            $table->index('created_at');
        Schema::create('photos', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('user_id')->constrained('users')->cascadeOnDelete();
            $table->uuid('album_id')->nullable()->constrained('photo_albums')->nullOnDelete();
            $table->string('title');
            $table->text('description')->nullable();
            $table->string('image_path');
            $table->string('image_disk')->default('public');
            $table->string('thumbnail_path')->nullable();
            $table->string('category')->nullable(); // Nature, Events, Recreation, Community, Sports, etc.
            $table->enum('status', ['pending', 'approved', 'rejected'])->default('pending');
            $table->unsignedInteger('width')->nullable();
            $table->unsignedInteger('height')->nullable();
            $table->unsignedBigInteger('file_size')->nullable(); // in bytes
            $table->unsignedInteger('views_count')->default(0);
            $table->unsignedInteger('likes_count')->default(0);
            $table->unsignedInteger('comments_count')->default(0);
```

## 2025_11_04_210911_add_author_fields_to_users_table.php
```php
                $table->text('bio')->nullable()->after('email');
                $table->string('author_slug')->nullable()->unique()->after('bio');
                $table->decimal('trust_score', 5, 2)->default(0.00)->after('author_slug');
                $table->enum('trust_tier', ['bronze', 'silver', 'gold', 'platinum'])->nullable()->after('trust_score');
                $table->boolean('is_verified_author')->default(false)->after('trust_tier');
                $table->json('author_metadata')->nullable()->after('is_verified_author');
            $table->dropColumn([
```

## 2025_11_04_210912_create_legal_notices_table.php
```php
        Schema::create('legal_notices', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignUuid('workspace_id')->nullable()->constrained()->nullOnDelete();
            $table->enum('type', [
            $table->string('case_number')->nullable();
            $table->string('title');
            $table->text('content');
            $table->string('court')->nullable();
            $table->date('publish_date');
            $table->date('expiry_date')->nullable();
            $table->enum('status', ['active', 'expires_soon', 'expired', 'removed'])->default('active');
            $table->json('metadata')->nullable(); // Store additional case-specific data
            $table->unsignedInteger('views_count')->default(0);
            $table->timestamps();
            $table->index(['type', 'status']);
            $table->index(['status', 'publish_date']);
            $table->index(['publish_date', 'expiry_date']);
            $table->index('case_number');
        Schema::create('legal_notice_region', function (Blueprint $table) {
            $table->id();
            $table->uuid('legal_notice_id')->constrained('legal_notices')->cascadeOnDelete();
            $table->foreignUuid('region_id')->constrained()->cascadeOnDelete();
            $table->timestamps();
            $table->unique(['legal_notice_id', 'region_id']);
```

## 2025_11_04_210913_create_memorials_table.php
```php
        Schema::create('memorials', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignUuid('workspace_id')->nullable()->constrained()->nullOnDelete();
            $table->string('name');
            $table->string('years'); // e.g., "1932 - 2023"
            $table->date('date_of_passing');
            $table->text('obituary');
            $table->string('image')->nullable();
            $table->string('location')->nullable();
            $table->date('service_date')->nullable();
            $table->string('service_location')->nullable();
            $table->text('service_details')->nullable();
            $table->boolean('is_featured')->default(false);
            $table->enum('status', ['draft', 'published', 'removed'])->default('draft');
            $table->timestamp('published_at')->nullable();
            $table->unsignedInteger('views_count')->default(0);
            $table->unsignedInteger('reactions_count')->default(0);
            $table->unsignedInteger('comments_count')->default(0);
            $table->timestamps();
            $table->index(['status', 'published_at']);
            $table->index(['date_of_passing', 'status']);
            $table->index('is_featured');
        Schema::create('memorial_region', function (Blueprint $table) {
            $table->id();
            $table->uuid('memorial_id')->constrained('memorials')->cascadeOnDelete();
            $table->foreignUuid('region_id')->constrained()->cascadeOnDelete();
            $table->timestamps();
            $table->unique(['memorial_id', 'region_id']);
```

## 2025_11_04_210914_create_podcasts_tables.php
```php
        Schema::create('creator_profiles', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('user_id')->constrained('users')->cascadeOnDelete();
            $table->string('display_name');
            $table->string('slug')->unique();
            $table->text('bio')->nullable();
            $table->string('avatar')->nullable();
            $table->string('cover_image')->nullable();
            $table->json('social_links')->nullable(); // Twitter, Instagram, etc.
            $table->enum('status', ['pending', 'approved', 'rejected', 'suspended'])->default('pending');
            $table->unsignedInteger('followers_count')->default(0);
            $table->unsignedInteger('podcasts_count')->default(0);
            $table->unsignedInteger('episodes_count')->default(0);
            $table->unsignedInteger('total_listens')->default(0);
            $table->timestamps();
            $table->index(['status', 'created_at']);
            $table->index('slug');
        Schema::create('podcasts', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('creator_profile_id')->constrained('creator_profiles')->cascadeOnDelete();
            $table->string('title');
            $table->string('slug')->unique();
            $table->text('description')->nullable();
            $table->string('cover_image')->nullable();
            $table->string('category')->nullable();
            $table->enum('status', ['draft', 'published', 'archived'])->default('draft');
            $table->timestamp('published_at')->nullable();
            $table->unsignedInteger('episodes_count')->default(0);
            $table->unsignedInteger('subscribers_count')->default(0);
            $table->unsignedInteger('total_listens')->default(0);
```

## 2025_11_17_105200_create_n8n_rss_integration_tables.php
```php
        Schema::create('businesses', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('workspace_id')->nullable()->constrained()->cascadeOnDelete();
            $table->string('google_place_id')->unique();
            $table->string('name');
            $table->string('slug')->unique();
            $table->text('description')->nullable();
            $table->string('website')->nullable();
            $table->string('phone')->nullable();
            $table->string('email')->nullable();
            $table->string('address')->nullable();
            $table->string('city')->nullable();
            $table->string('state')->nullable();
            $table->string('postal_code')->nullable();
            $table->string('country')->default('USA');
            $table->decimal('latitude', 10, 8)->nullable();
            $table->decimal('longitude', 11, 8)->nullable();
            $table->json('categories')->nullable();
            $table->decimal('rating', 3, 2)->nullable();
            $table->integer('reviews_count')->default(0);
            $table->json('opening_hours')->nullable();
            $table->json('images')->nullable();
            $table->json('serp_metadata')->nullable();
            $table->string('data_id')->nullable();
            $table->string('data_cid')->nullable();
            $table->string('lsig')->nullable();
            $table->string('provider_id')->nullable();
            $table->string('local_services_cid')->nullable();
            $table->string('local_services_bid')->nullable();
            $table->string('local_services_pid')->nullable();
```

## 2025_11_25_123429_create_news_workflow_tables.php
```php
        Schema::create('news_articles', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('region_id')->index();
            $table->uuid('business_id')->nullable()->index();
            $table->string('source_type'); // 'business' or 'category'
            $table->string('source_name');
            $table->text('title');
            $table->text('url')->unique();
            $table->text('content_snippet')->nullable();
            $table->text('full_content')->nullable();
            $table->string('source_publisher')->nullable();
            $table->timestamp('published_at')->nullable();
            $table->json('metadata')->nullable(); // Raw SERP data
            $table->string('content_hash')->index(); // Deduplication
            $table->boolean('processed')->default(false)->index();
            $table->timestamps();
            $table->foreign('region_id')->references('id')->on('regions')->cascadeOnDelete();
            $table->foreign('business_id')->references('id')->on('businesses')->cascadeOnDelete();
        Schema::create('news_article_drafts', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('news_article_id')->index();
            $table->uuid('region_id')->index();
            $table->string('status'); // shortlisted, outline_generated, ready_for_generation, ready_for_publishing, published, rejected
            $table->decimal('relevance_score', 5, 2)->nullable(); // Phase 3 AI scoring (0-100)
            $table->decimal('quality_score', 5, 2)->nullable(); // Phase 5 AI scoring (0-100)
            $table->decimal('fact_check_confidence', 5, 2)->nullable(); // Phase 4 average confidence (0-100) - STORED FOR UI
            $table->json('topic_tags')->nullable(); // Topic diversity tracking
            $table->text('outline')->nullable(); // Phase 4 generated outline
            $table->text('generated_title')->nullable(); // Phase 6
            $table->text('generated_content')->nullable(); // Phase 6
```

## 2025_11_26_201944_add_event_extraction_support.php
```php
            $table->foreignUuid('source_news_article_id')
                ->nullable()
                ->after('created_by')
                ->constrained('news_articles')
                ->nullOnDelete();
            $table->string('source_type')
                ->default('manual')
                ->after('source_news_article_id');
            $table->index('source_type');
        Schema::create('event_region', function (Blueprint $table) {
            $table->id();
            $table->foreignUuid('event_id')->constrained('events')->cascadeOnDelete();
            $table->foreignUuid('region_id')->constrained('regions')->cascadeOnDelete();
            $table->timestamps();
            $table->unique(['event_id', 'region_id']);
        Schema::create('event_extraction_drafts', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('news_article_id')->constrained('news_articles')->cascadeOnDelete();
            $table->foreignUuid('region_id')->constrained('regions')->cascadeOnDelete();
            $table->string('status')->default('pending');
            $table->decimal('detection_confidence', 5, 2)->nullable();
            $table->decimal('extraction_confidence', 5, 2)->nullable();
            $table->decimal('quality_score', 5, 2)->nullable();
            $table->json('extracted_data')->nullable();
            $table->foreignUuid('matched_venue_id')->nullable()->constrained('venues')->nullOnDelete();
            $table->foreignUuid('matched_performer_id')->nullable()->constrained('performers')->nullOnDelete();
            $table->foreignUuid('published_event_id')->nullable()->constrained('events')->nullOnDelete();
            $table->json('ai_metadata')->nullable();
            $table->text('rejection_reason')->nullable();
            $table->timestamps();
```

## 2025_11_27_124219_add_news_feature_enhancements.php
```php
            $table->string('featured_image_path')->nullable()->after('featured_image_url');
            $table->string('featured_image_disk')->nullable()->default('public')->after('featured_image_path');
            $table->string('featured_image_path')->nullable()->after('featured_image');
            $table->string('featured_image_disk')->nullable()->default('public')->after('featured_image_path');
            $table->string('image_path')->nullable()->after('image');
            $table->string('image_disk')->nullable()->default('public')->after('image_path');
            $table->decimal('relevance_score', 5, 2)->nullable()->after('processed');
            $table->json('relevance_topic_tags')->nullable()->after('relevance_score');
            $table->text('relevance_rationale')->nullable()->after('relevance_topic_tags');
            $table->timestamp('scored_at')->nullable()->after('relevance_rationale');
            $table->index(['region_id', 'relevance_score', 'processed']);
            $table->dropColumn(['featured_image_path', 'featured_image_disk']);
            $table->dropColumn(['featured_image_path', 'featured_image_disk']);
            $table->dropColumn(['image_path', 'image_disk']);
            $table->dropIndex(['region_id', 'relevance_score', 'processed']);
            $table->dropColumn(['relevance_score', 'relevance_topic_tags', 'relevance_rationale', 'scored_at']);
```

## 2025_12_10_215831_create_news_fetch_frequencies_table.php
```php
        Schema::create('news_fetch_frequencies', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('category')->index();
            $table->string('category_type'); // 'news_category' or 'business_category'
            $table->string('frequency_type'); // 'daily', 'weekly', 'monthly', 'custom_days'
            $table->unsignedInteger('custom_interval_days')->nullable();
            $table->timestamp('last_fetched_at')->nullable()->index();
            $table->boolean('is_enabled')->default(true)->index();
            $table->json('metadata')->nullable();
            $table->timestamps();
            $table->unique(['category', 'category_type']);
```

## 2025_12_11_163649_create_news_workflow_settings_table.php
```php
        Schema::create('news_workflow_settings', function (Blueprint $table) {
            $table->id();
            $table->string('key')->unique();
            $table->string('value');
            $table->string('type')->default('boolean');
            $table->text('description')->nullable();
            $table->timestamps();
```

## 2025_12_12_174756_extend_featured_image_url_length.php
```php
            $table->text('featured_image_url')->nullable()->change();
            $table->string('featured_image_url')->nullable()->change();
```

## 2025_12_16_112702_create_writer_agents_table.php
```php
        Schema::create('writer_agents', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('name');
            $table->string('slug')->unique();
            $table->text('bio')->nullable();
            $table->string('avatar')->nullable();
            $table->string('writing_style')->default('conversational');
            $table->json('persona_traits')->nullable();
            $table->json('expertise_areas')->nullable();
            $table->json('categories')->default('[]');
            $table->json('prompts')->default('{}');
            $table->unsignedInteger('articles_count')->default(0);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            $table->index('is_active');
            $table->index('writing_style');
        Schema::create('writer_agent_region', function (Blueprint $table) {
            $table->id();
            $table->foreignUuid('writer_agent_id')->constrained('writer_agents')->cascadeOnDelete();
            $table->foreignUuid('region_id')->constrained('regions')->cascadeOnDelete();
            $table->boolean('is_primary')->default(false);
            $table->timestamps();
            $table->unique(['writer_agent_id', 'region_id']);
            $table->index('region_id');
            $table->foreignUuid('writer_agent_id')
                ->nullable()
                ->after('author_id')
                ->constrained('writer_agents')
                ->nullOnDelete();
            $table->dropForeign(['writer_agent_id']);
```

## 2025_12_20_000001_add_organization_fields_to_businesses_table.php
```php
            $table->string('organization_type')->default('business')->after('status');
            $table->string('organization_level')->default('local')->after('organization_type');
            $table->uuid('parent_organization_id')->nullable()->after('organization_level');
            $table->string('organization_category')->nullable()->after('parent_organization_id');
            $table->boolean('is_organization')->default(false)->after('organization_category');
            $table->string('organization_identifier')->nullable()->after('is_organization');
            $table->json('organization_hierarchy')->nullable()->after('organization_identifier');
            $table->foreign('parent_organization_id')
                ->references('id')
                ->on('businesses')
                ->nullOnDelete();
            $table->index('organization_type');
            $table->index('organization_level');
            $table->index('parent_organization_id');
            $table->index('is_organization');
            $table->index('organization_category');
            $table->dropForeign(['parent_organization_id']);
            $table->dropIndex(['organization_type']);
            $table->dropIndex(['organization_level']);
            $table->dropIndex(['parent_organization_id']);
            $table->dropIndex(['is_organization']);
            $table->dropIndex(['organization_category']);
            $table->dropColumn([
```

## 2025_12_20_000002_create_organization_relationships_table.php
```php
        Schema::create('organization_relationships', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('organization_id');
            $table->string('relatable_type'); // e.g., 'App\Models\DayNewsPost', 'App\Models\Event', etc.
            $table->uuid('relatable_id');
            $table->string('relationship_type')->default('related');
            $table->boolean('is_primary')->default(false);
            $table->json('metadata')->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->foreign('organization_id')
                ->references('id')
                ->on('businesses')
                ->cascadeOnDelete();
            $table->unique(['organization_id', 'relatable_type', 'relatable_id', 'relationship_type'], 'org_rel_unique');
            $table->index(['relatable_type', 'relatable_id']);
            $table->index('relationship_type');
            $table->index('is_primary');
            $table->index('organization_id');
```

## 2025_12_20_000003_create_organization_hierarchies_table.php
```php
        Schema::create('organization_hierarchies', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('organization_id');
            $table->uuid('parent_id')->nullable();
            $table->integer('level')->default(0);
            $table->string('path', 500)->nullable();
            $table->timestamps();
            $table->foreign('organization_id')
                ->references('id')
                ->on('businesses')
                ->cascadeOnDelete();
            $table->foreign('parent_id')
                ->references('id')
                ->on('businesses')
                ->nullOnDelete();
            $table->unique(['organization_id', 'parent_id']);
            $table->index('organization_id');
            $table->index('parent_id');
            $table->index('level');
```

## 2025_12_20_142746_create_hubs_table.php
```php
        Schema::create('hubs', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('workspace_id');
            $table->uuid('created_by');
            $table->string('name');
            $table->string('slug')->unique();
            $table->text('description')->nullable();
            $table->string('image')->nullable();
            $table->string('banner_image')->nullable();
            $table->text('about')->nullable();
            $table->string('category')->nullable();
            $table->string('subcategory')->nullable();
            $table->string('location')->nullable();
            $table->string('website')->nullable();
            $table->json('social_links')->nullable();
            $table->string('contact_email')->nullable();
            $table->string('contact_phone')->nullable();
            $table->boolean('is_active')->default(true);
            $table->boolean('is_featured')->default(false);
            $table->boolean('is_verified')->default(false);
            $table->json('design_settings')->nullable();
            $table->json('monetization_settings')->nullable();
            $table->json('permissions')->nullable();
            $table->boolean('analytics_enabled')->default(true);
            $table->boolean('articles_enabled')->default(true);
            $table->boolean('community_enabled')->default(true);
            $table->boolean('events_enabled')->default(true);
            $table->boolean('gallery_enabled')->default(true);
            $table->boolean('performers_enabled')->default(true);
            $table->boolean('venues_enabled')->default(true);
```

## 2025_12_20_142758_create_check_ins_table.php
```php
        Schema::create('check_ins', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('event_id');
            $table->uuid('user_id');
            $table->timestamp('checked_in_at');
            $table->string('location')->nullable();
            $table->decimal('latitude', 10, 8)->nullable();
            $table->decimal('longitude', 11, 8)->nullable();
            $table->text('notes')->nullable();
            $table->boolean('is_public')->default(true);
            $table->timestamps();
            $table->foreign('event_id')->references('id')->on('events')->onDelete('cascade');
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            $table->unique(['event_id', 'user_id']);
            $table->index(['event_id', 'checked_in_at']);
            $table->index(['user_id', 'checked_in_at']);
```

## 2025_12_20_142759_create_planned_events_table.php
```php
        Schema::create('planned_events', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('event_id');
            $table->uuid('user_id');
            $table->timestamp('planned_at');
            $table->boolean('reminder_sent')->default(false);
            $table->timestamp('reminder_sent_at')->nullable();
            $table->text('notes')->nullable();
            $table->timestamps();
            $table->foreign('event_id')->references('id')->on('events')->onDelete('cascade');
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            $table->unique(['event_id', 'user_id']);
            $table->index(['user_id', 'planned_at']);
            $table->index(['event_id']);
```

## 2025_12_20_142800_create_promo_codes_table.php
```php
        Schema::create('promo_codes', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('code')->unique();
            $table->text('description')->nullable();
            $table->string('type'); // percentage or fixed
            $table->decimal('value', 10, 2);
            $table->decimal('min_purchase', 10, 2)->nullable();
            $table->decimal('max_discount', 10, 2)->nullable();
            $table->integer('usage_limit')->nullable();
            $table->integer('used_count')->default(0);
            $table->boolean('is_active')->default(true);
            $table->timestamp('starts_at')->nullable();
            $table->timestamp('expires_at')->nullable();
            $table->json('applicable_to')->nullable(); // event_ids, event_categories, etc.
            $table->json('metadata')->nullable();
            $table->timestamps();
            $table->index(['code', 'is_active']);
            $table->index(['expires_at']);
        Schema::create('promo_code_usages', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('promo_code_id');
            $table->uuid('user_id');
            $table->uuid('ticket_order_id');
            $table->decimal('discount_amount', 10, 2);
            $table->decimal('original_amount', 10, 2);
            $table->decimal('final_amount', 10, 2);
            $table->timestamp('used_at');
            $table->timestamps();
            $table->foreign('promo_code_id')->references('id')->on('promo_codes')->onDelete('cascade');
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
```

## 2025_12_20_142801_create_ticket_listings_table.php
```php
        Schema::create('ticket_listings', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('ticket_order_item_id');
            $table->uuid('seller_id');
            $table->uuid('event_id');
            $table->decimal('price', 10, 2);
            $table->integer('quantity');
            $table->string('status')->default('active'); // active, sold, cancelled, expired
            $table->text('description')->nullable();
            $table->timestamp('expires_at')->nullable();
            $table->timestamp('sold_at')->nullable();
            $table->uuid('sold_to')->nullable();
            $table->timestamps();
            $table->foreign('ticket_order_item_id')->references('id')->on('ticket_order_items')->onDelete('cascade');
            $table->foreign('seller_id')->references('id')->on('users')->onDelete('cascade');
            $table->foreign('event_id')->references('id')->on('events')->onDelete('cascade');
            $table->foreign('sold_to')->references('id')->on('users')->onDelete('set null');
            $table->index(['event_id', 'status']);
            $table->index(['seller_id', 'status']);
            $table->index(['status', 'expires_at']);
```

## 2025_12_20_142801_create_ticket_transfers_table.php
```php
        Schema::create('ticket_transfers', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('ticket_order_item_id');
            $table->uuid('from_user_id');
            $table->uuid('to_user_id')->nullable();
            $table->string('to_email');
            $table->string('status')->default('pending'); // pending, completed, cancelled, expired
            $table->string('transfer_token')->unique();
            $table->text('message')->nullable();
            $table->timestamp('transferred_at')->nullable();
            $table->timestamp('expires_at')->nullable();
            $table->timestamps();
            $table->foreign('ticket_order_item_id')->references('id')->on('ticket_order_items')->onDelete('cascade');
            $table->foreign('from_user_id')->references('id')->on('users')->onDelete('cascade');
            $table->foreign('to_user_id')->references('id')->on('users')->onDelete('set null');
            $table->index(['from_user_id', 'status']);
            $table->index(['to_email', 'status']);
            $table->index(['transfer_token']);
            $table->index(['status', 'expires_at']);
```

## 2025_12_20_142802_create_ticket_gifts_table.php
```php
        Schema::create('ticket_gifts', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('ticket_order_item_id');
            $table->uuid('gifter_id');
            $table->string('recipient_email');
            $table->string('recipient_name')->nullable();
            $table->uuid('recipient_user_id')->nullable();
            $table->string('status')->default('pending'); // pending, redeemed, cancelled, expired
            $table->string('gift_token')->unique();
            $table->text('message')->nullable();
            $table->timestamp('gifted_at')->nullable();
            $table->timestamp('redeemed_at')->nullable();
            $table->timestamp('expires_at')->nullable();
            $table->timestamps();
            $table->foreign('ticket_order_item_id')->references('id')->on('ticket_order_items')->onDelete('cascade');
            $table->foreign('gifter_id')->references('id')->on('users')->onDelete('cascade');
            $table->foreign('recipient_user_id')->references('id')->on('users')->onDelete('set null');
            $table->index(['gifter_id', 'status']);
            $table->index(['recipient_email', 'status']);
            $table->index(['gift_token']);
            $table->index(['status', 'expires_at']);
```

## 2025_12_20_182429_add_qr_code_to_ticket_order_items_table.php
```php
            $table->string('ticket_code')->unique()->nullable()->after('total_price');
            $table->string('qr_code')->nullable()->after('ticket_code');
            $table->index('ticket_code');
            $table->dropIndex(['ticket_code']);
            $table->dropColumn(['ticket_code', 'qr_code']);
```

## 2025_12_22_143009_create_industries_table.php
```php
        Schema::create('industries', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('name');
            $table->string('slug')->unique();
            $table->text('description')->nullable();
            $table->string('icon', 100)->nullable();
            $table->uuid('parent_id')->nullable();
            $table->uuid('default_template_id')->nullable();
            $table->json('available_features')->nullable();
            $table->json('required_fields')->nullable();
            $table->string('seo_title')->nullable();
            $table->text('seo_description')->nullable();
            $table->string('schema_type', 100)->nullable(); // LocalBusiness, Restaurant, etc.
            $table->integer('display_order')->default(0);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            $table->foreign('parent_id')->references('id')->on('industries')->nullOnDelete();
```

## 2025_12_22_143016_create_business_templates_table.php
```php
        Schema::create('business_templates', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('name');
            $table->string('slug')->unique();
            $table->text('description')->nullable();
            $table->uuid('industry_id')->nullable();
            $table->json('layout_config')->nullable();
            $table->json('available_tabs')->nullable();
            $table->json('default_tabs')->nullable();
            $table->json('ai_features')->nullable();
            $table->json('theme_config')->nullable();
            $table->json('component_overrides')->nullable();
            $table->json('seo_template')->nullable();
            $table->json('schema_template')->nullable();
            $table->boolean('is_premium')->default(false);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            $table->foreign('industry_id')->references('id')->on('industries')->nullOnDelete();
```

## 2025_12_22_143020_create_business_subscriptions_table.php
```php
        Schema::create('business_subscriptions', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('business_id');
            $table->string('tier', 50)->default('trial'); // trial, basic, standard, premium, enterprise
            $table->string('status', 50)->default('active'); // active, expired, cancelled, suspended
            $table->timestamp('trial_started_at')->useCurrent();
            $table->timestamp('trial_expires_at');
            $table->timestamp('trial_converted_at')->nullable();
            $table->timestamp('subscription_started_at')->nullable();
            $table->timestamp('subscription_expires_at')->nullable();
            $table->boolean('auto_renew')->default(true);
            $table->string('stripe_subscription_id')->nullable();
            $table->string('stripe_customer_id')->nullable();
            $table->decimal('monthly_amount', 10, 2)->nullable();
            $table->string('billing_cycle', 20)->default('monthly'); // monthly, annual
            $table->json('ai_services_enabled')->default('[]');
            $table->uuid('claimed_by_id')->nullable();
            $table->timestamp('claimed_at')->nullable();
            $table->timestamp('downgraded_at')->nullable();
            $table->timestamps();
            $table->foreign('business_id')->references('id')->on('businesses')->cascadeOnDelete();
            $table->foreign('claimed_by_id')->references('id')->on('users')->nullOnDelete();
            $table->index('business_id');
            $table->index('status');
            $table->index('tier');
            $table->index('trial_expires_at');
```

## 2025_12_22_143022_create_alphasite_communities_table.php
```php
        Schema::create('alphasite_communities', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('city');
            $table->string('state', 100);
            $table->string('country', 100)->default('US');
            $table->string('slug')->unique();
            $table->string('name');
            $table->text('description')->nullable();
            $table->string('hero_image_url', 500)->nullable();
            $table->string('logo_url', 500)->nullable();
            $table->integer('total_businesses')->default(0);
            $table->integer('premium_businesses')->default(0);
            $table->integer('total_categories')->default(0);
            $table->string('seo_title')->nullable();
            $table->text('seo_description')->nullable();
            $table->json('featured_categories')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamp('launched_at')->nullable();
            $table->timestamps();
            $table->index('slug');
            $table->index(['city', 'state']);
```

## 2025_12_22_143022_create_communities_table.php
```php
        Schema::create('communities', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('city');
            $table->string('state', 100);
            $table->string('country', 100)->default('US');
            $table->string('slug')->unique();
            $table->string('name');
            $table->text('description')->nullable();
            $table->string('hero_image_url', 500)->nullable();
            $table->string('logo_url', 500)->nullable();
            $table->integer('total_businesses')->default(0);
            $table->integer('premium_businesses')->default(0);
            $table->integer('total_categories')->default(0);
            $table->string('seo_title')->nullable();
            $table->text('seo_description')->nullable();
            $table->json('featured_categories')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamp('launched_at')->nullable();
            $table->timestamps();
            $table->index('slug');
            $table->index(['city', 'state']);
```

## 2025_12_22_143025_create_smb_crm_customers_table.php
```php
        Schema::create('smb_crm_customers', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('business_id');
            $table->string('first_name')->nullable();
            $table->string('last_name')->nullable();
            $table->string('email')->nullable();
            $table->string('phone', 50)->nullable();
            $table->string('source', 100)->nullable();
            $table->json('source_details')->nullable();
            $table->string('status', 50)->default('lead'); // lead, prospect, customer, inactive, churned
            $table->date('customer_since')->nullable();
            $table->timestamp('last_interaction_at')->nullable();
            $table->integer('health_score')->nullable();
            $table->decimal('lifetime_value', 10, 2)->nullable();
            $table->decimal('predicted_churn_risk', 5, 4)->nullable();
            $table->text('ai_notes')->nullable();
            $table->json('preferences')->nullable();
            $table->json('tags')->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->foreign('business_id')->references('id')->on('businesses')->cascadeOnDelete();
            $table->index('business_id');
            $table->index(['business_id', 'email']);
            $table->index(['business_id', 'status']);
```

## 2025_12_22_143028_create_smb_crm_interactions_table.php
```php
        Schema::create('smb_crm_interactions', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('business_id');
            $table->uuid('customer_id')->nullable();
            $table->string('interaction_type', 50); // ai_chat, phone, email, in_person, booking, order
            $table->string('channel', 50)->nullable();
            $table->string('direction', 20)->nullable(); // inbound, outbound
            $table->string('subject', 500)->nullable();
            $table->text('content')->nullable();
            $table->text('summary')->nullable();
            $table->string('handled_by', 50)->nullable(); // ai, human, ai_escalated
            $table->string('ai_service_used', 100)->nullable();
            $table->decimal('ai_confidence_score', 5, 4)->nullable();
            $table->text('escalated_reason')->nullable();
            $table->string('outcome', 100)->nullable();
            $table->string('sentiment', 50)->nullable();
            $table->integer('duration_seconds')->nullable();
            $table->json('metadata')->nullable();
            $table->timestamp('created_at')->useCurrent();
            $table->foreign('business_id')->references('id')->on('businesses')->cascadeOnDelete();
            $table->foreign('customer_id')->references('id')->on('smb_crm_customers')->nullOnDelete();
            $table->index('business_id');
            $table->index('customer_id');
            $table->index('interaction_type');
            $table->index('created_at');
```

## 2025_12_22_143030_create_business_faqs_table.php
```php
        Schema::create('business_faqs', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('business_id');
            $table->text('question');
            $table->text('answer');
            $table->string('category', 100)->nullable();
            $table->json('tags')->nullable();
            $table->json('variations')->nullable();
            $table->json('follow_up_questions')->nullable();
            $table->integer('times_used')->default(0);
            $table->integer('helpful_votes')->default(0);
            $table->integer('unhelpful_votes')->default(0);
            $table->boolean('is_active')->default(true);
            $table->integer('display_order')->default(0);
            $table->timestamps();
            $table->foreign('business_id')->references('id')->on('businesses')->cascadeOnDelete();
            $table->index('business_id');
            $table->index(['business_id', 'category']);
```

## 2025_12_22_143032_create_business_surveys_table.php
```php
        Schema::create('business_surveys', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('business_id');
            $table->string('name');
            $table->text('description')->nullable();
            $table->string('survey_type', 50)->nullable();
            $table->json('questions');
            $table->string('trigger_type', 50)->nullable();
            $table->json('trigger_config')->nullable();
            $table->boolean('is_active')->default(true);
            $table->integer('responses_count')->default(0);
            $table->decimal('average_score', 3, 2)->nullable();
            $table->timestamps();
            $table->foreign('business_id')->references('id')->on('businesses')->cascadeOnDelete();
            $table->index('business_id');
        Schema::create('business_survey_responses', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('survey_id');
            $table->uuid('business_id');
            $table->uuid('customer_id')->nullable();
            $table->json('responses');
            $table->decimal('overall_score', 3, 2)->nullable();
            $table->string('sentiment', 50)->nullable();
            $table->text('ai_summary')->nullable();
            $table->json('action_items')->nullable();
            $table->timestamp('completed_at')->useCurrent();
            $table->string('source', 50)->nullable();
            $table->timestamps();
            $table->foreign('survey_id')->references('id')->on('business_surveys')->cascadeOnDelete();
            $table->foreign('business_id')->references('id')->on('businesses')->cascadeOnDelete();
```

## 2025_12_22_143034_add_alphasite_fields_to_businesses_table.php
```php
            $table->string('alphasite_subdomain', 255)->unique()->nullable()->after('slug');
            $table->uuid('template_id')->nullable()->after('alphasite_subdomain');
            $table->boolean('ai_services_enabled')->default(false)->after('template_id');
            $table->timestamp('premium_enrolled_at')->nullable()->after('ai_services_enabled');
            $table->timestamp('premium_expires_at')->nullable()->after('premium_enrolled_at');
            $table->string('subscription_tier', 50)->default('free')->after('premium_expires_at');
            $table->json('homepage_content')->nullable()->after('subscription_tier');
            $table->json('social_links')->nullable()->after('homepage_content');
            $table->json('amenities')->nullable()->after('social_links');
            $table->boolean('featured')->default(false)->after('amenities');
            $table->boolean('promoted')->default(false)->after('featured');
            $table->json('seo_metadata')->nullable()->after('promoted');
            $table->uuid('industry_id')->nullable()->after('seo_metadata');
            $table->foreign('template_id')->references('id')->on('business_templates')->nullOnDelete();
            $table->foreign('industry_id')->references('id')->on('industries')->nullOnDelete();
            $table->index('alphasite_subdomain');
            $table->index('industry_id');
            $table->index('template_id');
            $table->index('subscription_tier');
            $table->index('featured');
            $table->index(['city', 'state']);
            $table->dropForeign(['template_id']);
            $table->dropForeign(['industry_id']);
            $table->dropIndex(['alphasite_subdomain']);
            $table->dropIndex(['industry_id']);
            $table->dropIndex(['template_id']);
            $table->dropIndex(['subscription_tier']);
            $table->dropIndex(['featured']);
            $table->dropIndex(['city', 'state']);
            $table->dropColumn([
```

## 2025_12_22_143036_create_achievements_table.php
```php
        Schema::create('achievements', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('business_id');
            $table->string('title');
            $table->text('description')->nullable();
            $table->string('source_name')->nullable();
            $table->string('source_url', 500)->nullable();
            $table->string('achievement_type', 100)->nullable();
            $table->date('achievement_date')->nullable();
            $table->date('expiration_date')->nullable();
            $table->string('icon', 100)->nullable();
            $table->string('badge_image_url', 500)->nullable();
            $table->boolean('is_verified')->default(false);
            $table->integer('display_order')->default(0);
            $table->boolean('is_featured')->default(false);
            $table->timestamps();
            $table->softDeletes();
            $table->foreign('business_id')->references('id')->on('businesses')->cascadeOnDelete();
            $table->index('business_id');
```

## 2025_12_22_174842_create_cross_domain_auth_tokens_table.php
```php
        Schema::create('cross_domain_auth_tokens', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('token', 64)->unique();
            $table->string('source_domain')->nullable(); // Domain where login occurred
            $table->json('target_domains')->nullable(); // Domains to sync to
            $table->timestamp('expires_at');
            $table->boolean('used')->default(false);
            $table->timestamps();
            $table->index(['token', 'expires_at', 'used']);
            $table->index('user_id');
```

## 2025_12_23_152656_add_alphasite_and_local_voices_to_advertisements_platform_enum.php
```php
            if (DB::connection()->getDriverName() === 'sqlite') {
                $table->dropColumn('platform');
                $table->enum('platform', ['day_news', 'event_city', 'downtown_guide', 'alphasite', 'local_voices'])->after('id');
                $table->dropColumn('platform');
                $table->addColumn('platform', 'advertisements_platform_enum_old')->after('id');
                $table->dropColumn('platform');
                $table->enum('platform', ['day_news', 'event_city', 'downtown_guide'])->after('id');
```

## 2025_12_23_200943_create_ad_campaigns_table.php
```php
        Schema::create('ad_campaigns', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('advertiser_id')->constrained('businesses')->cascadeOnDelete();
            $table->string('name');
            $table->text('description')->nullable();
            $table->enum('status', ['draft', 'pending', 'active', 'paused', 'completed', 'cancelled'])->default('draft');
            $table->enum('type', ['cpm', 'cpc', 'flat_rate', 'sponsored']);
            $table->decimal('budget', 12, 2);
            $table->decimal('spent', 12, 2)->default(0);
            $table->decimal('daily_budget', 10, 2)->nullable();
            $table->date('start_date');
            $table->date('end_date');
            $table->json('targeting')->nullable(); // communities, demographics, etc.
            $table->json('platforms')->nullable(); // day_news, goeventcity, etc.
            $table->timestamps();
            $table->softDeletes();
            $table->index(['status', 'start_date', 'end_date']);
            $table->index('advertiser_id');
```

## 2025_12_23_200945_create_ad_creatives_table.php
```php
        Schema::create('ad_creatives', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('campaign_id')->constrained('ad_campaigns')->cascadeOnDelete();
            $table->string('name');
            $table->enum('format', ['leaderboard', 'medium_rectangle', 'sidebar', 'native', 'sponsored_article', 'audio', 'video']);
            $table->string('headline')->nullable();
            $table->text('body')->nullable();
            $table->string('image_url')->nullable();
            $table->string('video_url')->nullable();
            $table->string('audio_url')->nullable();
            $table->string('click_url');
            $table->string('cta_text')->default('Learn More');
            $table->enum('status', ['draft', 'pending_review', 'approved', 'rejected', 'active', 'paused'])->default('draft');
            $table->integer('width')->nullable();
            $table->integer('height')->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->index(['campaign_id', 'status']);
            $table->index('format');
```

## 2025_12_23_200947_create_ad_placements_table.php
```php
        Schema::create('ad_placements', function (Blueprint $table) {
            $table->id();
            $table->string('platform'); // day_news, goeventcity, downtown_guide, alphasite_community, golocalvoices
            $table->string('slot'); // header_leaderboard, sidebar_top, in_article, footer, etc.
            $table->string('name');
            $table->text('description')->nullable();
            $table->string('format'); // leaderboard, medium_rectangle, etc.
            $table->integer('width');
            $table->integer('height');
            $table->decimal('base_cpm', 8, 2);
            $table->decimal('base_cpc', 8, 2)->nullable();
            $table->boolean('is_active')->default(true);
            $table->integer('priority')->default(0);
            $table->timestamps();
            $table->unique(['platform', 'slot']);
            $table->index('platform');
            $table->index('is_active');
```

## 2025_12_23_200950_create_ad_inventory_table.php
```php
        Schema::create('ad_inventory', function (Blueprint $table) {
            $table->id();
            $table->foreignId('placement_id')->constrained('ad_placements')->cascadeOnDelete();
            $table->foreignId('community_id')->constrained('communities')->cascadeOnDelete();
            $table->date('date');
            $table->integer('total_impressions')->default(0);
            $table->integer('sold_impressions')->default(0);
            $table->integer('delivered_impressions')->default(0);
            $table->decimal('revenue', 10, 2)->default(0);
            $table->timestamps();
            $table->unique(['placement_id', 'community_id', 'date']);
            $table->index(['date', 'placement_id']);
```

## 2025_12_23_200952_create_ad_impressions_table.php
```php
        Schema::create('ad_impressions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('creative_id')->constrained('ad_creatives')->cascadeOnDelete();
            $table->foreignId('placement_id')->constrained('ad_placements')->cascadeOnDelete();
            $table->foreignId('community_id')->nullable()->constrained('communities')->nullOnDelete();
            $table->string('session_id', 64)->nullable();
            $table->string('ip_hash', 64)->nullable();
            $table->string('user_agent')->nullable();
            $table->string('referrer')->nullable();
            $table->decimal('cost', 8, 4)->default(0);
            $table->timestamp('impressed_at');
            $table->timestamps();
            $table->index(['creative_id', 'impressed_at']);
            $table->index(['placement_id', 'impressed_at']);
            $table->index(['community_id', 'impressed_at']);
            $table->index('impressed_at');
```

## 2025_12_23_200954_create_ad_clicks_table.php
```php
        Schema::create('ad_clicks', function (Blueprint $table) {
            $table->id();
            $table->foreignId('impression_id')->constrained('ad_impressions')->cascadeOnDelete();
            $table->foreignId('creative_id')->constrained('ad_creatives')->cascadeOnDelete();
            $table->string('ip_hash', 64)->nullable();
            $table->decimal('cost', 8, 4)->default(0);
            $table->timestamp('clicked_at');
            $table->timestamps();
            $table->index(['creative_id', 'clicked_at']);
            $table->index('clicked_at');
```

## 2025_12_23_201529_create_email_subscribers_table.php
```php
        Schema::create('email_subscribers', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->string('email')->index();
            $table->string('first_name')->nullable();
            $table->string('last_name')->nullable();
            $table->foreignId('community_id')->constrained('communities')->cascadeOnDelete();
            $table->foreignId('business_id')->nullable()->constrained('businesses')->nullOnDelete();
            $table->enum('type', ['reader', 'smb'])->default('reader');
            $table->enum('status', ['pending', 'active', 'unsubscribed', 'bounced', 'complained'])->default('pending');
            $table->timestamp('confirmed_at')->nullable();
            $table->timestamp('unsubscribed_at')->nullable();
            $table->string('unsubscribe_reason')->nullable();
            $table->json('preferences')->nullable(); // daily_digest, breaking_news, weekly_newsletter
            $table->string('source')->nullable(); // signup_form, import, api, claim
            $table->timestamps();
            $table->softDeletes();
            $table->unique(['email', 'community_id']);
            $table->index(['community_id', 'status', 'type']);
```

## 2025_12_23_201530_create_email_campaigns_table.php
```php
        Schema::create('email_campaigns', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('community_id')->constrained('communities')->cascadeOnDelete();
            $table->foreignId('template_id')->nullable()->constrained('email_templates')->nullOnDelete();
            $table->string('name');
            $table->enum('type', ['daily_digest', 'breaking_news', 'weekly_newsletter', 'smb_report', 'emergency', 'custom']);
            $table->enum('status', ['draft', 'scheduled', 'sending', 'sent', 'cancelled'])->default('draft');
            $table->string('subject');
            $table->string('preview_text')->nullable();
            $table->longText('html_content')->nullable();
            $table->longText('text_content')->nullable();
            $table->json('segment')->nullable(); // targeting criteria
            $table->timestamp('scheduled_at')->nullable();
            $table->timestamp('started_at')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->integer('total_recipients')->default(0);
            $table->integer('sent_count')->default(0);
            $table->integer('delivered_count')->default(0);
            $table->integer('opened_count')->default(0);
            $table->integer('clicked_count')->default(0);
            $table->integer('bounced_count')->default(0);
            $table->integer('complained_count')->default(0);
            $table->integer('unsubscribed_count')->default(0);
            $table->timestamps();
            $table->index(['community_id', 'status']);
            $table->index(['type', 'status']);
            $table->index('scheduled_at');
```

## 2025_12_23_201530_create_email_sends_table.php
```php
        Schema::create('email_sends', function (Blueprint $table) {
            $table->id();
            $table->foreignId('campaign_id')->constrained('email_campaigns')->cascadeOnDelete();
            $table->foreignId('subscriber_id')->constrained('email_subscribers')->cascadeOnDelete();
            $table->string('message_id')->nullable()->index();
            $table->enum('status', ['queued', 'sent', 'delivered', 'bounced', 'complained', 'failed'])->default('queued');
            $table->timestamp('sent_at')->nullable();
            $table->timestamp('delivered_at')->nullable();
            $table->timestamp('opened_at')->nullable();
            $table->integer('open_count')->default(0);
            $table->timestamp('clicked_at')->nullable();
            $table->integer('click_count')->default(0);
            $table->string('bounce_type')->nullable();
            $table->text('error_message')->nullable();
            $table->timestamps();
            $table->unique(['campaign_id', 'subscriber_id']);
            $table->index(['campaign_id', 'status']);
            $table->index('sent_at');
```

## 2025_12_23_201530_create_email_templates_table.php
```php
        Schema::create('email_templates', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->string('name');
            $table->string('slug')->unique();
            $table->enum('type', ['daily_digest', 'breaking_news', 'weekly_newsletter', 'smb_report', 'emergency', 'transactional']);
            $table->string('subject_template');
            $table->string('preview_text')->nullable();
            $table->longText('html_template');
            $table->longText('text_template')->nullable();
            $table->json('variables')->nullable(); // List of available merge variables
            $table->boolean('is_active')->default(true);
            $table->integer('version')->default(1);
            $table->timestamps();
            $table->index(['type', 'is_active']);
```

## 2025_12_23_201530_create_newsletter_subscriptions_table.php
```php
        Schema::create('newsletter_subscriptions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('subscriber_id')->constrained('email_subscribers')->cascadeOnDelete();
            $table->enum('tier', ['free', 'paid'])->default('free');
            $table->decimal('price', 6, 2)->default(1.00);
            $table->string('stripe_subscription_id')->nullable();
            $table->enum('status', ['active', 'cancelled', 'past_due', 'paused'])->default('active');
            $table->timestamp('started_at');
            $table->timestamp('cancelled_at')->nullable();
            $table->timestamp('current_period_end')->nullable();
            $table->timestamps();
            $table->index(['subscriber_id', 'status']);
            $table->index('stripe_subscription_id');
```

## 2025_12_23_201533_create_emergency_alerts_table.php
```php
        Schema::create('emergency_alerts', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('community_id')->constrained('communities')->cascadeOnDelete();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('municipal_partner_id')->nullable();
            $table->enum('priority', ['critical', 'urgent', 'advisory', 'info'])->default('advisory');
            $table->string('category'); // weather, crime, health, utility, traffic, government, school, amber
            $table->string('title');
            $table->text('message');
            $table->text('instructions')->nullable();
            $table->string('source')->nullable();
            $table->string('source_url')->nullable();
            $table->enum('status', ['draft', 'active', 'expired', 'cancelled'])->default('draft');
            $table->timestamp('published_at')->nullable();
            $table->timestamp('expires_at')->nullable();
            $table->json('delivery_channels')->nullable(); // email, sms, push
            $table->integer('email_sent')->default(0);
            $table->integer('sms_sent')->default(0);
            $table->timestamps();
            $table->softDeletes();
            $table->index(['community_id', 'status', 'priority']);
            $table->index(['status', 'published_at']);
            $table->index('expires_at');
```

## 2025_12_23_201533_create_emergency_subscriptions_table.php
```php
        Schema::create('emergency_subscriptions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('subscriber_id')->constrained('email_subscribers')->cascadeOnDelete();
            $table->boolean('email_enabled')->default(true);
            $table->boolean('sms_enabled')->default(false);
            $table->string('phone_number')->nullable();
            $table->boolean('phone_verified')->default(false);
            $table->string('phone_verification_code')->nullable();
            $table->timestamp('phone_verified_at')->nullable();
            $table->json('priority_levels')->nullable(); // which priorities to receive
            $table->json('categories')->nullable(); // which categories to receive
            $table->string('stripe_subscription_id')->nullable(); // for SMS tier
            $table->enum('sms_tier', ['none', 'basic'])->default('none');
            $table->timestamps();
            $table->unique('subscriber_id');
            $table->index(['sms_enabled', 'phone_verified']);
```

## 2025_12_23_201534_create_emergency_audit_log_table.php
```php
        Schema::create('emergency_audit_log', function (Blueprint $table) {
            $table->id();
            $table->foreignId('alert_id')->nullable()->constrained('emergency_alerts')->nullOnDelete();
            $table->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('municipal_partner_id')->nullable()->constrained('municipal_partners')->nullOnDelete();
            $table->string('action'); // created, published, updated, cancelled, expired
            $table->json('changes')->nullable();
            $table->string('ip_address')->nullable();
            $table->string('user_agent')->nullable();
            $table->timestamps();
            $table->index(['alert_id', 'created_at']);
            $table->index(['user_id', 'created_at']);
            $table->index('created_at');
```

## 2025_12_23_201534_create_emergency_deliveries_table.php
```php
        Schema::create('emergency_deliveries', function (Blueprint $table) {
            $table->id();
            $table->foreignId('alert_id')->constrained('emergency_alerts')->cascadeOnDelete();
            $table->foreignId('subscription_id')->constrained('emergency_subscriptions')->cascadeOnDelete();
            $table->enum('channel', ['email', 'sms']);
            $table->enum('status', ['queued', 'sent', 'delivered', 'failed'])->default('queued');
            $table->string('external_id')->nullable(); // SES message ID or SNS message ID
            $table->timestamp('sent_at')->nullable();
            $table->timestamp('delivered_at')->nullable();
            $table->text('error_message')->nullable();
            $table->timestamps();
            $table->unique(['alert_id', 'subscription_id', 'channel']);
            $table->index(['alert_id', 'status']);
            $table->index('sent_at');
```

## 2025_12_23_201534_create_municipal_partners_table.php
```php
        Schema::create('municipal_partners', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->string('name');
            $table->enum('type', ['municipality', 'law_enforcement', 'school_district', 'utility', 'other']);
            $table->json('community_ids'); // communities they can broadcast to
            $table->foreignId('primary_contact_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('api_key_hash')->nullable();
            $table->boolean('is_verified')->default(false);
            $table->boolean('is_active')->default(true);
            $table->json('allowed_categories')->nullable();
            $table->json('allowed_priorities')->nullable();
            $table->boolean('requires_approval')->default(true);
            $table->timestamps();
            $table->softDeletes();
            $table->index(['is_active', 'is_verified']);
            $table->foreign('municipal_partner_id')
                ->references('id')
                ->on('municipal_partners')
                ->nullOnDelete();
            $table->dropForeign(['municipal_partner_id']);
```

## 2025_12_24_022805_create_notification_subscriptions_table.php
```php
        Schema::create('notification_subscriptions', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('user_id')->constrained('users')->onDelete('cascade');
            $table->enum('platform', ['daynews', 'goeventcity', 'downtownguide', 'alphasite'])->index();
            $table->string('community_id', 100)->nullable()->index();
            $table->uuid('business_id')->nullable(); // for Alphasite SMB notifications
            $table->string('phone_number', 20)->nullable()->index();
            $table->boolean('phone_verified')->default(false);
            $table->timestamp('phone_verified_at')->nullable();
            $table->text('web_push_endpoint')->nullable();
            $table->string('web_push_p256dh', 255)->nullable();
            $table->string('web_push_auth', 255)->nullable();
            $table->string('sns_sms_subscription_arn', 255)->nullable();
            $table->string('sns_endpoint_arn', 255)->nullable(); // for mobile app push
            $table->json('notification_types')->default('["breaking_news", "events", "deals"]');
            $table->enum('frequency', ['instant', 'daily_digest', 'weekly_digest'])->default('instant');
            $table->time('quiet_hours_start')->default('22:00');
            $table->time('quiet_hours_end')->default('08:00');
            $table->enum('status', ['active', 'paused', 'unsubscribed'])->default('active')->index();
            $table->timestamps();
            $table->timestamp('last_notification_at')->nullable();
            $table->unique(['user_id', 'platform', 'community_id'], 'unique_user_platform_community');
            $table->index(['platform', 'community_id', 'status'], 'idx_platform_community_status');
```

## 2025_12_24_022809_create_phone_verifications_table.php
```php
        Schema::create('phone_verifications', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('phone_number', 20)->index();
            $table->string('code', 6);
            $table->timestamp('expires_at');
            $table->integer('attempts')->default(0);
            $table->boolean('verified')->default(false);
            $table->timestamps();
            $table->index(['phone_number', 'code', 'expires_at'], 'idx_phone_code_expires');
```

## 2025_12_24_022813_create_notification_log_table.php
```php
        Schema::create('notification_log', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('platform', 50)->index();
            $table->string('community_id', 100)->nullable()->index();
            $table->string('notification_type', 50)->index();
            $table->enum('channel', ['sms', 'web_push', 'app_push', 'email'])->index();
            $table->string('title', 255)->nullable();
            $table->text('message');
            $table->json('payload')->nullable();
            $table->integer('recipient_count')->default(0);
            $table->string('sns_message_id', 255)->nullable();
            $table->enum('status', ['queued', 'sent', 'failed', 'partial'])->default('queued')->index();
            $table->text('error_message')->nullable();
            $table->timestamps();
            $table->timestamp('sent_at')->nullable();
            $table->index(['platform', 'created_at'], 'idx_platform_date');
            $table->index(['community_id', 'created_at'], 'idx_community_date');
            $table->index(['status', 'created_at'], 'idx_status_date');
```

## 2025_12_27_183628_create_tenants_table.php
```php
        Schema::create('tenants', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('name');
            $table->string('subdomain')->unique();
            $table->string('domain')->nullable()->unique();
            $table->string('email')->unique();
            $table->string('phone')->nullable();
            $table->string('address')->nullable();
            $table->string('city')->nullable();
            $table->string('state', 2)->nullable();
            $table->string('postal_code')->nullable();
            $table->string('country', 2)->default('US');
            $table->string('timezone')->default('America/New_York');
            $table->string('locale', 10)->default('en_US');
            $table->string('currency', 3)->default('USD');
            $table->boolean('is_active')->default(true);
            $table->timestamp('trial_ends_at')->nullable();
            $table->json('settings')->nullable();
            $table->json('metadata')->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->index('subdomain');
            $table->index('is_active');
```

## 2025_12_27_183629_create_account_managers_table.php
```php
        Schema::create('account_managers', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('tenant_id');
            $table->uuid('user_id');
            $table->string('first_name');
            $table->string('last_name');
            $table->string('email')->unique();
            $table->string('phone')->nullable();
            $table->boolean('is_active')->default(true);
            $table->integer('max_accounts')->default(50);
            $table->integer('current_account_count')->default(0);
            $table->json('metadata')->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->foreign('tenant_id')->references('id')->on('tenants')->cascadeOnDelete();
            $table->foreign('user_id')->references('id')->on('users')->cascadeOnDelete();
            $table->index('tenant_id');
            $table->index('user_id');
            $table->index('is_active');
```

## 2025_12_27_183629_create_business_hours_table.php
```php
        Schema::create('business_hours', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('smb_business_id');
            $table->integer('day_of_week'); // 0 = Sunday, 6 = Saturday
            $table->time('open_time')->nullable();
            $table->time('close_time')->nullable();
            $table->boolean('is_closed')->default(false);
            $table->boolean('is_24_hours')->default(false);
            $table->timestamps();
            $table->foreign('smb_business_id')->references('id')->on('smb_businesses')->cascadeOnDelete();
            $table->unique(['smb_business_id', 'day_of_week']);
            $table->index('smb_business_id');
```

## 2025_12_27_183629_create_customers_table.php
```php
        Schema::create('customers', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('tenant_id');
            $table->uuid('smb_business_id')->nullable();
            $table->string('first_name');
            $table->string('last_name');
            $table->string('email')->nullable();
            $table->string('phone')->nullable();
            $table->enum('lifecycle_stage', ['lead', 'mql', 'sql', 'customer'])->default('lead');
            $table->integer('lead_score')->default(0);
            $table->enum('lead_source', ['organic', 'paid', 'referral', 'direct'])->nullable();
            $table->boolean('email_opted_in')->default(false);
            $table->boolean('sms_opted_in')->default(false);
            $table->decimal('lifetime_value', 10, 2)->default(0);
            $table->json('tags')->nullable();
            $table->json('custom_fields')->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->foreign('tenant_id')->references('id')->on('tenants')->cascadeOnDelete();
            $table->foreign('smb_business_id')->references('id')->on('smb_businesses')->nullOnDelete();
            $table->index('tenant_id');
            $table->index('smb_business_id');
            $table->index('lifecycle_stage');
            $table->index('email');
```

## 2025_12_27_183629_create_smb_businesses_table.php
```php
        Schema::create('smb_businesses', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('tenant_id');
            $table->string('google_place_id')->unique();
            $table->string('display_name');
            $table->decimal('latitude', 10, 8);
            $table->decimal('longitude', 11, 8);
            $table->text('formatted_address');
            $table->json('address_components')->nullable();
            $table->string('plus_code')->nullable();
            $table->json('viewport')->nullable();
            $table->json('location')->nullable();
            $table->string('phone_national');
            $table->string('phone_international')->nullable();
            $table->string('website_url')->nullable();
            $table->string('business_status')->default('OPERATIONAL');
            $table->enum('fibonacco_status', ['prospect', 'active', 'churned'])->default('prospect');
            $table->decimal('google_rating', 3, 1)->nullable();
            $table->integer('google_rating_count')->default(0);
            $table->integer('user_rating_total')->default(0);
            $table->boolean('delivery')->default(false);
            $table->boolean('dine_in')->default(false);
            $table->boolean('takeout')->default(false);
            $table->boolean('reservable')->default(false);
            $table->boolean('outdoor_seating')->default(false);
            $table->boolean('serves_breakfast')->default(false);
            $table->boolean('serves_lunch')->default(false);
            $table->boolean('serves_dinner')->default(false);
            $table->boolean('serves_beer')->default(false);
            $table->boolean('serves_wine')->default(false);
```

## 2025_12_27_183630_create_business_attributes_table.php
```php
        Schema::create('business_attributes', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('smb_business_id');
            $table->string('attribute_key');
            $table->text('attribute_value')->nullable();
            $table->enum('attribute_type', ['boolean', 'string', 'array'])->default('string');
            $table->timestamps();
            $table->foreign('smb_business_id')->references('id')->on('smb_businesses')->cascadeOnDelete();
            $table->unique(['smb_business_id', 'attribute_key']);
            $table->index('smb_business_id');
```

## 2025_12_27_183630_create_business_photos_table.php
```php
        Schema::create('business_photos', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('smb_business_id');
            $table->string('photo_reference'); // Google Places photo reference
            $table->integer('width');
            $table->integer('height');
            $table->json('html_attributions')->nullable();
            $table->boolean('is_primary')->default(false);
            $table->integer('display_order')->default(0);
            $table->timestamps();
            $table->foreign('smb_business_id')->references('id')->on('smb_businesses')->cascadeOnDelete();
            $table->index('smb_business_id');
            $table->index(['smb_business_id', 'is_primary']);
            $table->index(['smb_business_id', 'display_order']);
```

## 2025_12_27_183630_create_business_reviews_table.php
```php
        Schema::create('business_reviews', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('smb_business_id');
            $table->string('author_name');
            $table->string('author_url')->nullable();
            $table->string('language', 10)->default('en');
            $table->string('profile_photo_url')->nullable();
            $table->integer('rating'); // 1-5
            $table->string('relative_time_description')->nullable();
            $table->text('text');
            $table->bigInteger('time'); // Unix timestamp
            $table->timestamps();
            $table->foreign('smb_business_id')->references('id')->on('smb_businesses')->cascadeOnDelete();
            $table->index('smb_business_id');
            $table->index('rating');
            $table->index('time');
```

## 2025_12_27_183630_create_deals_table.php
```php
        Schema::create('deals', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('tenant_id');
            $table->uuid('customer_id');
            $table->string('name');
            $table->decimal('amount', 10, 2);
            $table->string('currency', 3)->default('USD');
            $table->enum('stage', ['prospecting', 'qualification', 'proposal', 'negotiation', 'closed_won', 'closed_lost'])->default('prospecting');
            $table->integer('probability')->default(0); // 0-100
            $table->date('expected_close_date')->nullable();
            $table->date('actual_close_date')->nullable();
            $table->text('description')->nullable();
            $table->json('tags')->nullable();
            $table->json('custom_fields')->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->foreign('tenant_id')->references('id')->on('tenants')->cascadeOnDelete();
            $table->foreign('customer_id')->references('id')->on('customers')->cascadeOnDelete();
            $table->index('tenant_id');
            $table->index('customer_id');
            $table->index('stage');
            $table->index('expected_close_date');
```

## 2025_12_27_183630_create_interactions_table.php
```php
        Schema::create('interactions', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('tenant_id');
            $table->uuid('customer_id');
            $table->enum('type', ['email', 'phone', 'meeting', 'note', 'task', 'social'])->default('note');
            $table->string('subject');
            $table->text('description')->nullable();
            $table->enum('direction', ['inbound', 'outbound'])->default('inbound');
            $table->integer('duration_minutes')->nullable();
            $table->enum('outcome', ['positive', 'neutral', 'negative', 'no_response'])->nullable();
            $table->string('next_action')->nullable();
            $table->date('next_action_date')->nullable();
            $table->json('metadata')->nullable();
            $table->timestamps();
            $table->foreign('tenant_id')->references('id')->on('tenants')->cascadeOnDelete();
            $table->foreign('customer_id')->references('id')->on('customers')->cascadeOnDelete();
            $table->index('tenant_id');
            $table->index('customer_id');
            $table->index('type');
            $table->index('created_at');
```

## 2025_12_27_183630_create_tasks_table.php
```php
        Schema::create('tasks', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('tenant_id');
            $table->uuid('customer_id');
            $table->uuid('assigned_to_id');
            $table->string('title');
            $table->text('description')->nullable();
            $table->enum('type', ['call', 'email', 'meeting', 'follow_up', 'other'])->default('other');
            $table->enum('priority', ['low', 'medium', 'high', 'urgent'])->default('medium');
            $table->enum('status', ['pending', 'in_progress', 'completed', 'cancelled'])->default('pending');
            $table->date('due_date')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->json('metadata')->nullable();
            $table->timestamps();
            $table->foreign('tenant_id')->references('id')->on('tenants')->cascadeOnDelete();
            $table->foreign('customer_id')->references('id')->on('customers')->cascadeOnDelete();
            $table->foreign('assigned_to_id')->references('id')->on('users')->cascadeOnDelete();
            $table->index('tenant_id');
            $table->index('customer_id');
            $table->index('assigned_to_id');
            $table->index('status');
            $table->index('due_date');
```

## 2025_12_27_183631_create_campaign_recipients_table.php
```php
        Schema::create('campaign_recipients', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('campaign_id');
            $table->uuid('customer_id');
            $table->enum('status', ['pending', 'sent', 'delivered', 'opened', 'clicked', 'bounced', 'unsubscribed'])->default('pending');
            $table->timestamp('sent_at')->nullable();
            $table->timestamp('delivered_at')->nullable();
            $table->timestamp('opened_at')->nullable();
            $table->timestamp('clicked_at')->nullable();
            $table->timestamp('bounced_at')->nullable();
            $table->timestamp('unsubscribed_at')->nullable();
            $table->json('metadata')->nullable();
            $table->timestamps();
            $table->foreign('campaign_id')->references('id')->on('campaigns')->cascadeOnDelete();
            $table->foreign('customer_id')->references('id')->on('customers')->cascadeOnDelete();
            $table->unique(['campaign_id', 'customer_id']);
            $table->index('campaign_id');
            $table->index('customer_id');
            $table->index('status');
```

## 2025_12_27_183631_create_campaigns_table.php
```php
        Schema::create('campaigns', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('tenant_id');
            $table->string('name');
            $table->enum('type', ['email', 'sms', 'social', 'direct_mail', 'event'])->default('email');
            $table->enum('status', ['draft', 'scheduled', 'active', 'paused', 'completed', 'cancelled'])->default('draft');
            $table->timestamp('start_date')->nullable();
            $table->timestamp('end_date')->nullable();
            $table->decimal('budget', 10, 2)->nullable();
            $table->decimal('spent', 10, 2)->default(0);
            $table->json('target_audience')->nullable();
            $table->text('content')->nullable();
            $table->json('metadata')->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->foreign('tenant_id')->references('id')->on('tenants')->cascadeOnDelete();
            $table->index('tenant_id');
            $table->index('status');
            $table->index('start_date');
```

## 2025_12_27_185918_add_tenant_id_to_users_table.php
```php
            $table->uuid('tenant_id')->nullable()->after('id');
            $table->foreign('tenant_id')->references('id')->on('tenants')->nullOnDelete();
            $table->index('tenant_id');
            $table->dropForeign(['tenant_id']);
            $table->dropIndex(['tenant_id']);
            $table->dropColumn('tenant_id');
```

## 2025_12_28_011832_add_slug_to_events_table.php
```php
                $table->string('slug')->nullable()->unique()->after('title');
            $table->dropColumn('slug');
```

## 2025_12_28_011850_add_image_fields_to_events_table.php
```php
                $table->string('image_path')->nullable()->after('image');
                $table->string('image_disk')->nullable()->after('image_path');
            $table->dropColumn(['image_path', 'image_disk']);
```

## 2025_12_28_011852_add_source_fields_to_events_table.php
```php
                $table->uuid('source_news_article_id')->nullable()->after('created_by');
                $table->string('source_type')->nullable()->after('source_news_article_id');
            $table->dropColumn(['source_news_article_id', 'source_type']);
```

