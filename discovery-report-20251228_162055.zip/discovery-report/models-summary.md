# Models Summary

## AccountManager
```php
    protected $fillable = [
    protected function casts(): array
    public function tenant(): BelongsTo
        return $this->belongsTo(Tenant::class);
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function getFullNameAttribute(): string
    public function hasCapacity(): bool
```

## Achievement
```php
    protected $fillable = [
    protected function casts(): array
    public function business(): BelongsTo
        return $this->belongsTo(Business::class);
    public function scopeFeatured($query)
    public function scopeVerified($query)
    public function scopeActive($query)
        return $query->where(function ($q) {
```

## AdCampaign
```php
    protected $fillable = [
    protected $casts = [
    protected static function boot(): void
        static::creating(function ($model): void {
    public function advertiser(): BelongsTo
        return $this->belongsTo(Business::class, 'advertiser_id');
    public function creatives(): HasMany
        return $this->hasMany(AdCreative::class, 'campaign_id');
    public function isActive(): bool
    public function getRemainingBudgetAttribute(): float
```

## AdClick
```php
    protected $fillable = [
    protected $casts = [
    public function impression(): BelongsTo
        return $this->belongsTo(AdImpression::class, 'impression_id');
    public function creative(): BelongsTo
        return $this->belongsTo(AdCreative::class, 'creative_id');
```

## AdCreative
```php
    protected $fillable = [
    protected static function boot(): void
        static::creating(function ($model): void {
    public function campaign(): BelongsTo
        return $this->belongsTo(AdCampaign::class, 'campaign_id');
    public function impressions(): HasMany
        return $this->hasMany(AdImpression::class, 'creative_id');
    public function clicks(): HasMany
        return $this->hasMany(AdClick::class, 'creative_id');
    public function getCtrAttribute(): float
```

## AdImpression
```php
    protected $fillable = [
    protected $casts = [
    public function creative(): BelongsTo
        return $this->belongsTo(AdCreative::class, 'creative_id');
    public function placement(): BelongsTo
        return $this->belongsTo(AdPlacement::class, 'placement_id');
    public function community(): BelongsTo
        return $this->belongsTo(Community::class, 'community_id');
    public function click(): HasOne
        return $this->hasOne(AdClick::class, 'impression_id');
```

## AdInventory
```php
    protected $fillable = [
    protected $casts = [
    public function placement(): BelongsTo
        return $this->belongsTo(AdPlacement::class, 'placement_id');
    public function community(): BelongsTo
        return $this->belongsTo(Community::class, 'community_id');
```

## AdPlacement
```php
    protected $fillable = [
    protected $casts = [
    public function inventory(): HasMany
        return $this->hasMany(AdInventory::class, 'placement_id');
    public function impressions(): HasMany
        return $this->hasMany(AdImpression::class, 'placement_id');
```

## Advertisement
```php
    protected $fillable = [
    public function advertable(): MorphTo
        return $this->morphTo();
    public function scopeActive($query)
    public function scopeForPlatform($query, string $platform)
    public function scopeForPlacement($query, string $placement)
    public function scopeForRegion($query, string $regionId)
    public function scopeExpired($query)
    public function incrementImpressions(): void
    public function incrementClicks(): void
    public function markAsInactive(): void
    public function isExpired(): bool
    public function getClickThroughRate(): float
    public function getCTR(): string
    protected function casts(): array
```

## AlphaSiteCommunity
```php
    protected $fillable = [
    protected function casts(): array
    public function businesses(): HasMany
        return $this->hasMany(Business::class, 'city', 'city')
    public function scopeActive($query)
```

## Announcement
```php
    protected $fillable = [
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function workspace(): BelongsTo
        return $this->belongsTo(Workspace::class);
    public function regions(): BelongsToMany
        return $this->belongsToMany(Region::class, 'announcement_region')
    public function comments(): MorphMany
        return $this->morphMany(ArticleComment::class, 'article_id'); // Reuse ArticleComment pattern
    public function scopePublished($query)
            ->where(function ($q) {
    public function scopeByType($query, string $type)
    public function scopeUpcoming($query)
        return $query->where(function ($q) {
    public function scopeForRegion($query, int $regionId)
        return $query->whereHas('regions', function ($q) use ($regionId) {
    public function incrementViewsCount(): void
    public function incrementReactionsCount(): void
    public function incrementCommentsCount(): void
    protected function casts(): array
```

## ArticleComment
```php
    protected $fillable = [
    public function article(): BelongsTo
        return $this->belongsTo(DayNewsPost::class, 'article_id');
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function parent(): BelongsTo
        return $this->belongsTo(self::class, 'parent_id');
    public function replies(): HasMany
        return $this->hasMany(self::class, 'parent_id');
    public function likes(): HasMany
        return $this->hasMany(ArticleCommentLike::class, 'comment_id');
    public function activities(): MorphMany
        return $this->morphMany(SocialActivity::class, 'subject');
    public function isLikedBy(User $user): bool
    public function likesCount(): int
    public function repliesCount(): int
    public function scopeTopLevel($query)
    public function scopeActive($query)
    public function scopePinned($query)
    public function scopeBest($query)
    public function scopeNewest($query)
    public function scopeOldest($query)
    protected function casts(): array
```

## ArticleCommentLike
```php
    protected $fillable = [
    public function comment(): BelongsTo
        return $this->belongsTo(ArticleComment::class, 'comment_id');
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
```

## Booking
```php
    protected $fillable = [
    public function event(): BelongsTo
        return $this->belongsTo(Event::class);
    public function venue(): BelongsTo
        return $this->belongsTo(Venue::class);
    public function performer(): BelongsTo
        return $this->belongsTo(Performer::class);
    public function workspace(): BelongsTo
        return $this->belongsTo(Workspace::class);
    public function createdBy(): BelongsTo
        return $this->belongsTo(User::class, 'created_by');
    public function getContactInfoAttribute(): array
    public function getPaymentAttribute(): array
    public function scopeByStatus($query, string $status)
    public function scopeByType($query, string $type)
    public function scopePending($query)
    public function scopeConfirmed($query)
    public function scopeForDate($query, string $date)
    public function scopeForDateRange($query, string $from, string $to)
    public function scopeEventBookings($query)
    public function scopeVenueBookings($query)
    public function scopePerformerBookings($query)
    public function isEventBooking(): bool
    public function isVenueBooking(): bool
    public function isPerformerBooking(): bool
    public function isPaid(): bool
    public function isPartiallyPaid(): bool
    public function isPending(): bool
    public function isConfirmed(): bool
    public function isCancelled(): bool
    public function markAsConfirmed(): void
    public function markAsCancelled(?string $reason = null): void
    protected static function boot(): void
        self::creating(function ($booking) {
    protected function casts(): array
```

## Business
```php
    protected $fillable = [
    public function workspace(): BelongsTo
        return $this->belongsTo(Workspace::class);
    public function regions(): BelongsToMany
        return $this->belongsToMany(Region::class)->withTimestamps();
    public function claimable(): MorphTo
        return $this->morphTo();
    public function rssFeeds(): HasMany
        return $this->hasMany(RssFeed::class);
    public function healthyRssFeeds(): HasMany
        return $this->hasMany(RssFeed::class)
    public function parentOrganization(): BelongsTo
        return $this->belongsTo(Business::class, 'parent_organization_id');
    public function childOrganizations(): HasMany
        return $this->hasMany(Business::class, 'parent_organization_id');
    public function organizationRelationships(): HasMany
        return $this->hasMany(\App\Models\OrganizationRelationship::class, 'organization_id');
    public function relatedContent(string $type = null): HasMany
        $query = $this->hasMany(\App\Models\OrganizationRelationship::class, 'organization_id');
    public function industry(): BelongsTo
        return $this->belongsTo(Industry::class);
    public function template(): BelongsTo
        return $this->belongsTo(BusinessTemplate::class, 'template_id');
    public function subscription(): BelongsTo
        return $this->belongsTo(BusinessSubscription::class, 'business_id');
    public function achievements(): HasMany
        return $this->hasMany(Achievement::class);
    public function featuredAchievements(): HasMany
        return $this->hasMany(Achievement::class)->where('is_featured', true);
    public function faqs(): HasMany
        return $this->hasMany(BusinessFaq::class);
    public function activeFaqs(): HasMany
        return $this->hasMany(BusinessFaq::class)->where('is_active', true);
    public function surveys(): HasMany
        return $this->hasMany(BusinessSurvey::class);
    public function activeSurveys(): HasMany
        return $this->hasMany(BusinessSurvey::class)->where('is_active', true);
    public function crmCustomers(): HasMany
        return $this->hasMany(SMBCrmCustomer::class);
    public function crmInteractions(): HasMany
        return $this->hasMany(SMBCrmInteraction::class);
    public function scopeActive($query)
    public function scopeInactive($query)
    public function scopeVerified($query)
    public function scopeClaimed($query)
    public function scopeUnclaimed($query)
    public function scopeInRegion($query, string $regionId)
        return $query->whereHas('regions', function ($q) use ($regionId) {
    public function scopeWithHealthyFeeds($query)
        return $query->whereHas('rssFeeds', function ($q) {
```

## BusinessAttribute
```php
    protected $fillable = [
    protected function casts(): array
    public function smbBusiness(): BelongsTo
        return $this->belongsTo(SmbBusiness::class);
```

## BusinessFaq
```php
    protected $fillable = [
    protected function casts(): array
    public function business(): BelongsTo
        return $this->belongsTo(Business::class);
    public function scopeActive($query)
```

## BusinessHours
```php
    protected $fillable = [
    protected function casts(): array
    public function smbBusiness(): BelongsTo
        return $this->belongsTo(SmbBusiness::class);
    public function getDayNameAttribute(): string
```

## BusinessPhoto
```php
    protected $fillable = [
    protected function casts(): array
    public function smbBusiness(): BelongsTo
        return $this->belongsTo(SmbBusiness::class);
```

## BusinessReview
```php
    protected $fillable = [
    protected function casts(): array
    public function smbBusiness(): BelongsTo
        return $this->belongsTo(SmbBusiness::class);
    public function isPositive(): bool
    public function isNegative(): bool
```

## BusinessSubscription
```php
    protected $fillable = [
    protected function casts(): array
    public function business(): BelongsTo
        return $this->belongsTo(Business::class);
    public function claimedBy(): BelongsTo
        return $this->belongsTo(User::class, 'claimed_by_id');
    public function isTrial(): bool
    public function isPremium(): bool
    public function isExpired(): bool
```

## BusinessSurvey
```php
    protected $fillable = [
    protected function casts(): array
    public function business(): BelongsTo
        return $this->belongsTo(Business::class);
    public function responses(): HasMany
        return $this->hasMany(BusinessSurveyResponse::class, 'survey_id');
    public function scopeActive($query)
```

## BusinessSurveyResponse
```php
    protected $fillable = [
    protected function casts(): array
    public function survey(): BelongsTo
        return $this->belongsTo(BusinessSurvey::class, 'survey_id');
    public function business(): BelongsTo
        return $this->belongsTo(Business::class);
    public function customer(): BelongsTo
        return $this->belongsTo(SMBCrmCustomer::class, 'customer_id');
```

## BusinessTemplate
```php
    protected $fillable = [
    protected function casts(): array
    public function industry(): BelongsTo
        return $this->belongsTo(Industry::class);
    public function businesses(): HasMany
        return $this->hasMany(Business::class, 'template_id');
    public function scopeActive($query)
```

## Calendar
```php
    protected $fillable = [
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function followers(): BelongsToMany
        return $this->belongsToMany(User::class, 'calendar_followers')
    public function events(): BelongsToMany
        return $this->belongsToMany(Event::class, 'calendar_events')
    public function roles(): HasMany
        return $this->hasMany(CalendarRole::class);
    public function editors(): BelongsToMany
        return $this->belongsToMany(User::class, 'calendar_roles')
    public function follows(): MorphMany
        return $this->morphMany(Follow::class, 'followable');
    public function scopePublic($query)
    public function scopePrivate($query)
    public function scopeFree($query)
    public function scopePaid($query)
    public function scopeByCategory($query, string $category)
    public function scopeVerified($query)
    protected function casts(): array
```

## CalendarEvent
```php
    protected $fillable = [
    public function calendar(): BelongsTo
        return $this->belongsTo(Calendar::class);
    public function event(): BelongsTo
        return $this->belongsTo(Event::class);
    public function addedBy(): BelongsTo
        return $this->belongsTo(User::class, 'added_by');
    protected function casts(): array
```

## CalendarFollower
```php
    protected $fillable = [
    public function calendar(): BelongsTo
        return $this->belongsTo(Calendar::class);
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
```

## CalendarRole
```php
    protected $fillable = [
    public function calendar(): BelongsTo
        return $this->belongsTo(Calendar::class);
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
```

## Campaign
```php
    protected $fillable = [
    protected function casts(): array
    public function tenant(): BelongsTo
        return $this->belongsTo(Tenant::class);
    public function recipients(): HasMany
        return $this->hasMany(CampaignRecipient::class);
    public function isActive(): bool
    public function isCompleted(): bool
```

## CampaignRecipient
```php
    protected $fillable = [
    protected function casts(): array
    public function campaign(): BelongsTo
        return $this->belongsTo(Campaign::class);
    public function customer(): BelongsTo
        return $this->belongsTo(Customer::class);
    public function hasOpened(): bool
    public function hasClicked(): bool
    public function hasBounced(): bool
```

## Cart
```php
    protected $fillable = [
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function items(): HasMany
        return $this->hasMany(CartItem::class);
    public function getItemsCountAttribute(): int
    public function getTotalAttribute(): float
        return $this->items()->get()->sum(function ($item) {
    public function getStoreIdsAttribute(): array
```

## CartItem
```php
    protected $fillable = [
    protected $casts = [
    public function cart(): BelongsTo
        return $this->belongsTo(Cart::class);
    public function product(): BelongsTo
        return $this->belongsTo(Product::class);
    public function store(): BelongsTo
        return $this->belongsTo(Store::class);
    public function getTotalAttribute(): float
```

## CheckIn
```php
    protected $fillable = [
    protected function casts(): array
    public function event(): BelongsTo
        return $this->belongsTo(Event::class);
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function scopeForEvent($query, string $eventId)
    public function scopeForUser($query, string $userId)
    public function scopePublic($query)
    public function scopeRecent($query, int $hours = 24)
```

## Classified
```php
    protected $fillable = [
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function workspace(): BelongsTo
        return $this->belongsTo(Workspace::class);
    public function images(): HasMany
        return $this->hasMany(ClassifiedImage::class, 'classified_id')->orderBy('order');
    public function regions(): BelongsToMany
        return $this->belongsToMany(Region::class, 'classified_region')
    public function payment(): HasOne
        return $this->hasOne(ClassifiedPayment::class, 'classified_id');
    public function scopeActive($query)
            ->where(function ($q) {
    public function scopeByCategory($query, string $category)
    public function scopeFeatured($query)
    public function scopeForRegion($query, int $regionId)
        return $query->whereHas('regions', function ($q) use ($regionId) {
    public function incrementViewsCount(): void
    public function isExpired(): bool
    protected function casts(): array
```

## ClassifiedImage
```php
    protected $fillable = [
    public function classified(): BelongsTo
        return $this->belongsTo(Classified::class, 'classified_id');
    public function getImageUrlAttribute(): string
```

## ClassifiedPayment
```php
    protected $fillable = [
    public function classified(): BelongsTo
        return $this->belongsTo(Classified::class, 'classified_id');
    public function workspace(): BelongsTo
        return $this->belongsTo(Workspace::class);
    public function isPaid(): bool
    public function markAsPaid(): void
    public function markAsFailed(): void
    public function getAmountInDollars(): float
    protected function casts(): array
```

## CommentReport
```php
    protected $fillable = [
    public function comment(): BelongsTo
        return $this->belongsTo(ArticleComment::class, 'comment_id');
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    protected function casts(): array
```

## Community
```php
    protected $fillable = [
    public function workspace(): BelongsTo
        return $this->belongsTo(Workspace::class);
    public function createdBy(): BelongsTo
        return $this->belongsTo(User::class, 'created_by');
    public function threads(): HasMany
        return $this->hasMany(CommunityThread::class);
    public function members(): HasMany
        return $this->hasMany(CommunityMember::class);
    public function activeMembers(): HasMany
        return $this->hasMany(CommunityMember::class)->active();
    public function getMemberCountAttribute(): int
    public function getActiveTodayAttribute(): int
    public function scopeActive($query)
    protected function casts(): array
```

## CommunityMember
```php
    protected $fillable = [
    public function community(): BelongsTo
        return $this->belongsTo(Community::class);
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function scopeActive($query)
    public function scopeByRole($query, string $role)
    public function scopeRecentlyActive($query, int $days = 30)
    protected function casts(): array
```

## CommunityThread
```php
    protected $fillable = [
    public function community(): BelongsTo
        return $this->belongsTo(Community::class);
    public function author(): BelongsTo
        return $this->belongsTo(User::class, 'author_id');
    public function lastReplyBy(): BelongsTo
        return $this->belongsTo(User::class, 'last_reply_by');
    public function replies(): HasMany
        return $this->hasMany(CommunityThreadReply::class, 'thread_id');
    public function views(): HasMany
        return $this->hasMany(CommunityThreadView::class, 'thread_id');
    public function topLevelReplies(): HasMany
        return $this->hasMany(CommunityThreadReply::class, 'thread_id')->topLevel();
    public function solutions(): HasMany
        return $this->hasMany(CommunityThreadReply::class, 'thread_id')->solutions();
    public function getViewsCountAttribute(): int
    public function getReplyCountAttribute(): int
    public function scopePinned($query)
    public function scopeUnlocked($query)
    public function scopeByType($query, string $type)
    protected function casts(): array
```

## CommunityThreadReply
```php
    protected $fillable = [
    public function thread(): BelongsTo
        return $this->belongsTo(CommunityThread::class, 'thread_id');
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function author(): BelongsTo
        return $this->belongsTo(User::class, 'user_id');
    public function replyTo(): BelongsTo
        return $this->belongsTo(self::class, 'reply_to_id');
    public function replies(): HasMany
        return $this->hasMany(self::class, 'reply_to_id');
    public function likes(): HasMany
        return $this->hasMany(CommunityThreadReplyLike::class, 'reply_id');
    public function getLikesCountAttribute(): int
    public function scopePinned($query)
    public function scopeSolutions($query)
    public function scopeTopLevel($query)
    public function scopeByUser($query, string $userId)
    public function scopeRecent($query)
    protected function casts(): array
```

## CommunityThreadReplyLike
```php
    protected $fillable = [
    public function reply(): BelongsTo
        return $this->belongsTo(CommunityThreadReply::class, 'reply_id');
    public function user(): BelongsTo
        return $this->belongsTo(User::class, 'user_id');
```

## CommunityThreadView
```php
    protected $fillable = [
    protected $casts = [
    public function thread(): BelongsTo
        return $this->belongsTo(CommunityThread::class, 'thread_id');
    public function user(): BelongsTo
        return $this->belongsTo(User::class, 'user_id');
```

## Conversation
```php
    protected $fillable = [
    public function participants(): BelongsToMany
        return $this->belongsToMany(User::class, 'conversation_participants')
    public function messages(): HasMany
        return $this->hasMany(Message::class);
    public function latestMessage(): HasOne
        return $this->hasOne(Message::class)->latestOfMany('created_at');
    public function conversationParticipants(): HasMany
        return $this->hasMany(ConversationParticipant::class);
    public function getUnreadCountForUser(string $userId): int
    public function markAsReadForUser(string $userId): void
    public function isPrivate(): bool
    public function isGroup(): bool
    protected function casts(): array
```

## ConversationParticipant
```php
    protected $fillable = [
    public function conversation(): BelongsTo
        return $this->belongsTo(Conversation::class);
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    protected function casts(): array
```

## Coupon
```php
    protected $fillable = [
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function business(): BelongsTo
        return $this->belongsTo(Business::class);
    public function regions(): BelongsToMany
        return $this->belongsToMany(Region::class, 'coupon_region')
    public function usages(): HasMany
        return $this->hasMany(CouponUsage::class, 'coupon_id');
    public function scopeActive($query)
    public function scopeExpired($query)
    public function scopeForRegion($query, int $regionId)
        return $query->whereHas('regions', function ($q) use ($regionId) {
    public function scopeByBusiness($query, int $businessId)
    public function isActive(): bool
    public function isExpired(): bool
    public function canBeUsed(): bool
    public function incrementViewsCount(): void
    public function incrementClicksCount(): void
    public function recordUsage(?int $userId = null, ?string $ipAddress = null): void
    protected static function booted(): void
        self::creating(function (Coupon $coupon): void {
    protected static function generateUniqueCode(): string
    protected function casts(): array
```

## CouponUsage
```php
    protected $fillable = [
    public function coupon(): BelongsTo
        return $this->belongsTo(Coupon::class, 'coupon_id');
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
```

## CreatorProfile
```php
    protected $fillable = [
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function podcasts(): HasMany
        return $this->hasMany(Podcast::class, 'creator_profile_id');
    public function followers(): MorphMany
        return $this->morphMany(Follow::class, 'followable');
    public function scopeApproved($query)
    public function incrementFollowersCount(): void
    public function incrementPodcastsCount(): void
    public function incrementEpisodesCount(): void
    protected static function booted(): void
        self::creating(function (CreatorProfile $profile): void {
    protected static function generateUniqueSlug(string $name): string
    protected function casts(): array
```

## CrossDomainAuthToken
```php
    protected $fillable = [
    protected $casts = [
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function isValid(): bool
    public function markAsUsed(): void
```

## Customer
```php
    protected $fillable = [
    protected function casts(): array
    public function tenant(): BelongsTo
        return $this->belongsTo(Tenant::class);
    public function smbBusiness(): BelongsTo
        return $this->belongsTo(SmbBusiness::class);
    public function deals(): HasMany
        return $this->hasMany(Deal::class);
    public function interactions(): HasMany
        return $this->hasMany(Interaction::class);
    public function tasks(): HasMany
        return $this->hasMany(Task::class);
    public function campaignRecipients(): HasMany
        return $this->hasMany(CampaignRecipient::class);
    public function getFullNameAttribute(): string
```

## DayNewsPost
```php
    protected $fillable = [
    public function workspace(): BelongsTo
        return $this->belongsTo(Workspace::class);
    public function author(): BelongsTo
        return $this->belongsTo(User::class, 'author_id');
    public function writerAgent(): BelongsTo
        return $this->belongsTo(WriterAgent::class);
    public function getDisplayAuthorAttribute(): ?string
    public function getDisplayAuthorAvatarAttribute(): ?string
    public function regions(): BelongsToMany
        return $this->belongsToMany(Region::class, 'day_news_post_region')
    public function payment(): HasOne
        return $this->hasOne(DayNewsPostPayment::class, 'post_id');
    public function advertisements(): MorphMany
        return $this->morphMany(Advertisement::class, 'advertable');
    public function rssFeed(): BelongsTo
        return $this->belongsTo(RssFeed::class);
    public function rssFeedItem(): BelongsTo
        return $this->belongsTo(RssFeedItem::class);
    public function comments(): HasMany
        return $this->hasMany(ArticleComment::class, 'article_id');
    public function activeComments(): HasMany
    public function tags(): BelongsToMany
        return $this->belongsToMany(Tag::class, 'day_news_post_tag')
    public function activities(): MorphMany
        return $this->morphMany(SocialActivity::class, 'subject');
    public function scopePublished($query)
            ->where(function ($q) {
    public function scopeActive($query)
    public function scopeForRegion($query, int $regionId)
        return $query->whereHas('regions', function ($q) use ($regionId) {
    public function scopeByType($query, string $type)
    public function scopeDraft($query)
    public function scopeExpired($query)
            ->orWhere(function ($q) {
    public function scopeForWorkspace($query, int $workspaceId)
    public function incrementViewCount(): void
    public function isExpired(): bool
    public function isFreeCategory(): bool
    public function getFeaturedImageAttribute(): ?string
    protected static function booted(): void
        self::creating(function (DayNewsPost $post): void {
    protected static function generateUniqueSlug(string $title): string
    protected function casts(): array
```

## DayNewsPostPayment
```php
    protected $fillable = [
    public function post(): BelongsTo
        return $this->belongsTo(DayNewsPost::class, 'post_id');
    public function workspace(): BelongsTo
        return $this->belongsTo(Workspace::class);
    public function scopePaid($query)
    public function scopePending($query)
    public function scopeFailed($query)
    public function isPaid(): bool
    public function markAsPaid(): void
    public function markAsFailed(): void
    public function getAmountInDollars(): float
    protected function casts(): array
```

## Deal
```php
    protected $fillable = [
    protected function casts(): array
    public function tenant(): BelongsTo
        return $this->belongsTo(Tenant::class);
    public function customer(): BelongsTo
        return $this->belongsTo(Customer::class);
    public function isWon(): bool
    public function isLost(): bool
    public function isOpen(): bool
```

## EmailCampaign
```php
    protected $fillable = [
    protected $casts = [
    protected static function boot(): void
        static::creating(function ($model): void {
    public function community(): BelongsTo
        return $this->belongsTo(Community::class);
    public function template(): BelongsTo
        return $this->belongsTo(EmailTemplate::class);
    public function sends(): HasMany
        return $this->hasMany(EmailSend::class, 'campaign_id');
    public function getOpenRateAttribute(): float
    public function getClickRateAttribute(): float
```

## EmailSend
```php
    protected $fillable = [
    protected $casts = [
    public function campaign(): BelongsTo
        return $this->belongsTo(EmailCampaign::class, 'campaign_id');
    public function subscriber(): BelongsTo
        return $this->belongsTo(EmailSubscriber::class, 'subscriber_id');
```

## EmailSubscriber
```php
    protected $fillable = [
    protected $casts = [
    protected static function boot(): void
        static::creating(function ($model): void {
    public function community(): BelongsTo
        return $this->belongsTo(Community::class);
    public function business(): BelongsTo
        return $this->belongsTo(Business::class);
    public function sends(): HasMany
        return $this->hasMany(EmailSend::class, 'subscriber_id');
    public function newsletterSubscription(): HasOne
        return $this->hasOne(NewsletterSubscription::class, 'subscriber_id');
    public function emergencySubscription(): HasOne
        return $this->hasOne(EmergencySubscription::class, 'subscriber_id');
    public function getFullNameAttribute(): string
    public function wantsDigest(): bool
    public function wantsBreakingNews(): bool
    public function wantsNewsletter(): bool
```

## EmailTemplate
```php
    protected $fillable = [
    protected $casts = [
    protected static function boot(): void
        static::creating(function ($model): void {
```

## EmergencyAlert
```php
    protected $fillable = [
    protected $casts = [
    protected static function boot(): void
        static::creating(function ($model): void {
    public function community(): BelongsTo
        return $this->belongsTo(Community::class);
    public function creator(): BelongsTo
        return $this->belongsTo(User::class, 'created_by');
    public function municipalPartner(): BelongsTo
        return $this->belongsTo(MunicipalPartner::class);
    public function deliveries(): HasMany
        return $this->hasMany(EmergencyDelivery::class, 'alert_id');
    public function auditLogs(): HasMany
        return $this->hasMany(EmergencyAuditLog::class, 'alert_id');
    public function isActive(): bool
    public function getPriorityColorAttribute(): string
```

## EmergencyAuditLog
```php
    protected $fillable = [
    protected $casts = [
    public function alert(): BelongsTo
        return $this->belongsTo(EmergencyAlert::class, 'alert_id');
    public function user(): BelongsTo
        return $this->belongsTo(User::class, 'user_id');
    public function municipalPartner(): BelongsTo
        return $this->belongsTo(MunicipalPartner::class, 'municipal_partner_id');
```

## EmergencyDelivery
```php
    protected $fillable = [
    protected $casts = [
    public function alert(): BelongsTo
        return $this->belongsTo(EmergencyAlert::class, 'alert_id');
    public function subscription(): BelongsTo
        return $this->belongsTo(EmergencySubscription::class, 'subscription_id');
```

## EmergencySubscription
```php
    protected $fillable = [
    protected $casts = [
    public function subscriber(): BelongsTo
        return $this->belongsTo(EmailSubscriber::class, 'subscriber_id');
    public function deliveries(): HasMany
        return $this->hasMany(EmergencyDelivery::class, 'subscription_id');
    public function shouldReceiveAlert(EmergencyAlert $alert): bool
    public function canReceiveSms(): bool
```

## Event
```php
    protected $appends = [
    protected $fillable = [
    public function venue(): BelongsTo
        return $this->belongsTo(Venue::class);
    public function performer(): BelongsTo
        return $this->belongsTo(Performer::class);
    public function workspace(): BelongsTo
        return $this->belongsTo(Workspace::class);
    public function createdBy(): BelongsTo
        return $this->belongsTo(User::class, 'created_by');
    public function sourceNewsArticle(): BelongsTo
        return $this->belongsTo(NewsArticle::class, 'source_news_article_id');
    public function regions(): BelongsToMany
        return $this->belongsToMany(Region::class, 'event_region')
    public function bookings(): HasMany
        return $this->hasMany(Booking::class);
    public function ticketPlans(): HasMany
        return $this->hasMany(TicketPlan::class);
    public function ticketOrders(): HasMany
        return $this->hasMany(TicketOrder::class);
    public function hub(): BelongsTo
        return $this->belongsTo(Hub::class);
    public function checkIns(): HasMany
        return $this->hasMany(CheckIn::class);
    public function plannedEvents(): HasMany
        return $this->hasMany(PlannedEvent::class);
    public function follows(): MorphMany
        return $this->morphMany(Follow::class, 'followable');
    public function getDateAttribute(): string
    public function getVenueInfoAttribute(): array
    public function getPriceAttribute(): array
    public function getLocationAttribute(): array
    public function getVenueModelAttribute(): ?Venue
    public function getImageAttribute(): ?string
    public function scopePublished($query)
    public function scopeUpcoming($query)
    public function scopeByCategory($query, string $category)
    public function scopeWithBadge($query, string $badge)
    public function scopeFree($query)
    public function scopeAiExtracted($query)
    public function scopeManual($query)
    public function scopeWithinPriceRange($query, float $min, float $max)
        return $query->where(function ($q) use ($min, $max) {
                ->orWhere(function ($q2) use ($min, $max) {
    public function scopeWithinRadius($query, float $lat, float $lng, float $radius)
    protected function casts(): array
```

## EventExtractionDraft
```php
    protected $fillable = [
    public function newsArticle(): BelongsTo
        return $this->belongsTo(NewsArticle::class);
    public function region(): BelongsTo
        return $this->belongsTo(Region::class);
    public function matchedVenue(): BelongsTo
        return $this->belongsTo(Venue::class, 'matched_venue_id');
    public function matchedPerformer(): BelongsTo
        return $this->belongsTo(Performer::class, 'matched_performer_id');
    public function publishedEvent(): BelongsTo
        return $this->belongsTo(Event::class, 'published_event_id');
    public function scopeByStatus($query, string $status)
    public function scopePending($query)
    public function scopeDetected($query)
    public function scopeExtracted($query)
    public function scopeValidated($query)
    public function scopePublished($query)
    public function scopeRejected($query)
    public function scopeForRegion($query, string $regionId)
    public function scopeAboveQualityThreshold($query, float $threshold)
    public function shouldAutoPublish(): bool
    protected function casts(): array
```

## Follow
```php
    protected $fillable = [
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function followable(): MorphTo
        return $this->morphTo();
    protected function casts(): array
```

## Hub
```php
    protected $fillable = [
    protected function casts(): array
    public function workspace(): BelongsTo
        return $this->belongsTo(Workspace::class);
    public function createdBy(): BelongsTo
        return $this->belongsTo(User::class, 'created_by');
    public function sections(): HasMany
        return $this->hasMany(HubSection::class)->orderBy('sort_order');
    public function members(): HasMany
        return $this->hasMany(HubMember::class);
    public function roles(): HasMany
        return $this->hasMany(HubRole::class);
    public function analytics(): HasMany
        return $this->hasMany(HubAnalytics::class);
    public function events(): HasMany
        return $this->hasMany(Event::class, 'hub_id');
    public function follows(): MorphMany
        return $this->morphMany(Follow::class, 'followable');
    public function scopeActive($query)
    public function scopeFeatured($query)
    public function scopeVerified($query)
    public function scopePublished($query)
    public static function generateUniqueSlug(string $name): string
    public function getUrlAttribute(): string
```

## HubAnalytics
```php
    protected $fillable = [
    protected function casts(): array
    public function hub(): BelongsTo
        return $this->belongsTo(Hub::class);
    public function scopeForDateRange($query, string $startDate, string $endDate)
    public function scopeRecent($query, int $days = 30)
```

## HubMember
```php
    protected $fillable = [
    protected function casts(): array
    public function hub(): BelongsTo
        return $this->belongsTo(Hub::class);
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function scopeActive($query)
    public function scopeRole($query, string $role)
    public function canEdit(): bool
    public function canManage(): bool
```

## HubRole
```php
    protected $fillable = [
    protected function casts(): array
    public function hub(): BelongsTo
        return $this->belongsTo(Hub::class);
    public function members(): HasMany
        return $this->hasMany(HubMember::class, 'role', 'slug');
```

## HubSection
```php
    protected $fillable = [
    protected function casts(): array
    public function hub(): BelongsTo
        return $this->belongsTo(Hub::class);
```

## Industry
```php
    protected $fillable = [
    protected function casts(): array
    public function parent(): BelongsTo
        return $this->belongsTo(Industry::class, 'parent_id');
    public function children(): HasMany
        return $this->hasMany(Industry::class, 'parent_id');
    public function defaultTemplate(): BelongsTo
        return $this->belongsTo(BusinessTemplate::class, 'default_template_id');
    public function businesses(): HasMany
        return $this->hasMany(Business::class, 'industry_id');
    public function templates(): HasMany
        return $this->hasMany(BusinessTemplate::class, 'industry_id');
    public function scopeActive($query)
```

## Interaction
```php
    protected $fillable = [
    protected function casts(): array
    public function tenant(): BelongsTo
        return $this->belongsTo(Tenant::class);
    public function customer(): BelongsTo
        return $this->belongsTo(Customer::class);
    public function isInbound(): bool
    public function isOutbound(): bool
```

## LegalNotice
```php
    protected $fillable = [
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function workspace(): BelongsTo
        return $this->belongsTo(Workspace::class);
    public function regions(): BelongsToMany
        return $this->belongsToMany(Region::class, 'legal_notice_region')
    public function scopeActive($query)
            ->where(function ($q) {
    public function scopeByType($query, string $type)
    public function scopeForRegion($query, int $regionId)
        return $query->whereHas('regions', function ($q) use ($regionId) {
    public function scopeExpiresSoon($query)
    public function incrementViewsCount(): void
    public function isExpired(): bool
    protected function casts(): array
```

## Memorial
```php
    protected $fillable = [
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function workspace(): BelongsTo
        return $this->belongsTo(Workspace::class);
    public function regions(): BelongsToMany
        return $this->belongsToMany(Region::class, 'memorial_region')
    public function scopePublished($query)
    public function scopeFeatured($query)
    public function scopeForRegion($query, int $regionId)
        return $query->whereHas('regions', function ($q) use ($regionId) {
    public function incrementViewsCount(): void
    public function incrementReactionsCount(): void
    public function incrementCommentsCount(): void
    protected function casts(): array
```

## Message
```php
    protected $fillable = [
    public function conversation(): BelongsTo
        return $this->belongsTo(Conversation::class);
    public function sender(): BelongsTo
        return $this->belongsTo(User::class, 'sender_id');
    public function isText(): bool
    public function isImage(): bool
    public function isFile(): bool
    public function isSystem(): bool
    public function isEdited(): bool
    public function markAsEdited(): void
    protected function casts(): array
```

## MunicipalPartner
```php
    protected $fillable = [
    protected $casts = [
    protected static function boot(): void
        static::creating(function ($model): void {
    public function primaryContact(): BelongsTo
        return $this->belongsTo(User::class, 'primary_contact_id');
    public function alerts(): HasMany
        return $this->hasMany(EmergencyAlert::class, 'municipal_partner_id');
```

## NewsArticle
```php
    protected $fillable = [
    public function region(): BelongsTo
        return $this->belongsTo(Region::class);
    public function business(): BelongsTo
        return $this->belongsTo(Business::class);
    public function drafts(): HasMany
        return $this->hasMany(NewsArticleDraft::class);
    public function eventExtractionDrafts(): HasMany
        return $this->hasMany(EventExtractionDraft::class);
    public function scopeUnprocessed($query)
    public function scopeProcessed($query)
    public function scopeForRegion($query, string $regionId)
    public function scopeForBusiness($query, string $businessId)
    public function scopeBySourceType($query, string $sourceType)
    public function scopeScored($query)
    public function scopeUnscored($query)
    public function markAsProcessed(): void
    public function isScored(): bool
    protected function casts(): array
```

## NewsArticleDraft
```php
    protected $fillable = [
    public function newsArticle(): BelongsTo
        return $this->belongsTo(NewsArticle::class);
    public function region(): BelongsTo
        return $this->belongsTo(Region::class);
    public function publishedPost(): BelongsTo
        return $this->belongsTo(DayNewsPost::class, 'published_post_id');
    public function factChecks(): HasMany
        return $this->hasMany(NewsFactCheck::class, 'draft_id');
    public function scopeByStatus($query, string $status)
    public function scopeShortlisted($query)
    public function scopeOutlineGenerated($query)
    public function scopeReadyForGeneration($query)
    public function scopeReadyForPublishing($query)
    public function scopePublished($query)
    public function scopeRejected($query)
    public function scopeForRegion($query, string $regionId)
    public function scopeAboveQualityThreshold($query, float $threshold)
    public function shouldAutoPublish(): bool
    public function calculateAverageFactCheckConfidence(): void
    public function getFeaturedImageUrlAttribute(): ?string
    protected function casts(): array
```

## NewsFactCheck
```php
    protected $fillable = [
    public function draft(): BelongsTo
        return $this->belongsTo(NewsArticleDraft::class, 'draft_id');
    public function scopeVerified($query)
    public function scopeUnverified($query)
    public function scopeContradicted($query)
    public function scopeAboveConfidence($query, float $threshold)
    public function scopeForDraft($query, string $draftId)
    public function isVerified(): bool
    public function isUnverified(): bool
    public function isContradicted(): bool
    protected function casts(): array
```

## NewsFetchFrequency
```php
    protected $fillable = [
    public static function frequencyOptions(): array
    public static function categoryTypeOptions(): array
    public function scopeEnabled(Builder $query): Builder
    public function scopeForNewsCategories(Builder $query): Builder
    public function scopeForBusinessCategories(Builder $query): Builder
    public function scopeForCategory(Builder $query, string $category, string $categoryType): Builder
    public function getIntervalInDays(): int
    public function shouldFetchToday(): bool
    public function markAsFetched(): void
    public function getNextFetchDate(): ?\Carbon\CarbonInterface
    protected function casts(): array
```

## NewsWorkflowRun
```php
    protected $fillable = [
    public function region(): BelongsTo
        return $this->belongsTo(Region::class);
    public function scopeForRegion($query, string $regionId)
    public function scopeByPhase($query, string $phase)
    public function scopeRunning($query)
    public function scopeCompleted($query)
    public function scopeFailed($query)
    public function scopeRecent($query, int $days = 7)
    public function isRunning(): bool
    public function isCompleted(): bool
    public function isFailed(): bool
    public function getDuration(): ?int
    protected function casts(): array
```

## NewsWorkflowSetting
```php
    protected $fillable = [
    public static function get(string $key, mixed $default = null): mixed
    public static function set(string $key, mixed $value, ?string $description = null): void
    public static function getAllCached(): array
        return Cache::remember(self::CACHE_KEY, self::CACHE_TTL, function () {
    public static function clearCache(): void
    private static function castValue(string $value, string $type): mixed
```

## NewsletterSubscription
```php
    protected $fillable = [
    protected $casts = [
    public function subscriber(): BelongsTo
        return $this->belongsTo(EmailSubscriber::class, 'subscriber_id');
```

## Notification
```php
    protected $fillable = [
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function markAsRead(): void
    public function scopeUnread($query)
    public function scopeForUser($query, $userId)
    protected function casts(): array
```

## NotificationLog
```php
    protected $fillable = [
    protected $casts = [
    public function scopeForPlatform($query, string $platform)
    public function scopeForCommunity($query, string $communityId)
    public function scopeByStatus($query, string $status)
    public function markAsSent(): void
    public function markAsFailed(string $errorMessage): void
    public function markAsPartial(): void
```

## NotificationSubscription
```php
    protected $fillable = [
    protected $casts = [
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function business(): BelongsTo
        return $this->belongsTo(Business::class);
    public function scopeActive($query)
    public function scopeForPlatform($query, string $platform)
    public function scopeForCommunity($query, string $communityId)
    public function scopeHasSms($query)
    public function scopeHasWebPush($query)
    public function isQuietHours(): bool
    public function wantsNotificationType(string $type): bool
    public function isActive(): bool
```

## Order
```php
    protected $fillable = [
    public function store(): BelongsTo
        return $this->belongsTo(Store::class);
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function items(): HasMany
        return $this->hasMany(OrderItem::class);
    public function isPaid(): bool
    public function isPending(): bool
    public function isProcessing(): bool
    public function isCompleted(): bool
    public function isCancelled(): bool
    public function isRefunded(): bool
    protected static function booted(): void
        self::creating(function (Order $order) {
    protected function casts(): array
```

## OrderItem
```php
    protected $fillable = [
    public function order(): BelongsTo
        return $this->belongsTo(Order::class);
    public function product(): BelongsTo
        return $this->belongsTo(Product::class);
    protected function casts(): array
```

## OrganizationHierarchy
```php
    protected $fillable = [
    public function organization(): BelongsTo
        return $this->belongsTo(Business::class, 'organization_id');
    public function parent(): BelongsTo
        return $this->belongsTo(Business::class, 'parent_id');
    public function scopeByLevel($query, int $level)
    public function scopeRoots($query)
    protected function casts(): array
```

## OrganizationRelationship
```php
    protected $fillable = [
    public function organization(): BelongsTo
        return $this->belongsTo(Business::class, 'organization_id');
    public function relatable(): MorphTo
        return $this->morphTo();
    public function scopePrimary($query)
    public function scopeByRelationshipType($query, string $type)
    public function scopeByRelatableType($query, string $type)
    public function scopeForOrganization($query, string $organizationId)
    protected function casts(): array
```

## Performer
```php
    protected $fillable = [
    public function workspace(): BelongsTo
        return $this->belongsTo(Workspace::class);
    public function createdBy(): BelongsTo
        return $this->belongsTo(User::class, 'created_by');
    public function events(): HasMany
        return $this->hasMany(Event::class);
    public function bookings(): HasMany
        return $this->hasMany(Booking::class);
    public function upcomingShows(): HasMany
        return $this->hasMany(UpcomingShow::class);
    public function follows(): MorphMany
        return $this->morphMany(Follow::class, 'followable');
    public function getImageAttribute(): ?string
    public function getUpcomingShowAttribute(): ?array
    public function getDistanceMilesAttribute(): float
    public function scopeActive($query)
    public function scopeVerified($query)
    public function scopeAvailableForBooking($query)
    public function scopeByGenre($query, string $genre)
    public function scopeFamilyFriendly($query)
    public function scopeTrending($query)
    public function scopeWithinRadius($query, float $lat, float $lng, float $radius)
    protected function casts(): array
```

## PhoneVerification
```php
    protected $fillable = [
    protected $casts = [
    public function scopeValid($query)
    public function scopeForPhone($query, string $phoneNumber)
    public function isExpired(): bool
    public function incrementAttempts(): void
```

## Photo
```php
    protected $fillable = [
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function album(): BelongsTo
        return $this->belongsTo(PhotoAlbum::class, 'album_id');
    public function albums(): BelongsToMany
        return $this->belongsToMany(PhotoAlbum::class, 'photo_album_photo')
    public function regions(): BelongsToMany
        return $this->belongsToMany(Region::class, 'photo_region')
    public function getImageUrlAttribute(): string
    public function getThumbnailUrlAttribute(): ?string
    public function scopeApproved($query)
    public function scopeByCategory($query, string $category)
    public function scopeForRegion($query, int $regionId)
        return $query->whereHas('regions', function ($q) use ($regionId) {
    public function scopePublic($query)
        return $query->whereHas('album', function ($q) {
    public function incrementViewsCount(): void
    public function incrementLikesCount(): void
    public function incrementCommentsCount(): void
    protected function casts(): array
```

## PhotoAlbum
```php
    protected $fillable = [
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function workspace(): BelongsTo
        return $this->belongsTo(Workspace::class);
    public function photos(): BelongsToMany
        return $this->belongsToMany(Photo::class, 'photo_album_photo')
    public function getRegionsAttribute()
        return Region::whereHas('photos', function ($q) {
    public function incrementViewsCount(): void
    public function incrementPhotosCount(): void
    protected function casts(): array
```

## PlannedEvent
```php
    protected $fillable = [
    protected function casts(): array
    public function event(): BelongsTo
        return $this->belongsTo(Event::class);
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function scopeForUser($query, string $userId)
    public function scopeUpcoming($query)
        return $query->whereHas('event', function ($q) {
    public function scopeNeedsReminder($query, int $hoursBefore = 24)
            ->whereHas('event', function ($q) use ($hoursBefore) {
```

## Podcast
```php
    protected $fillable = [
    public function creator(): BelongsTo
        return $this->belongsTo(CreatorProfile::class, 'creator_profile_id');
    public function episodes(): HasMany
        return $this->hasMany(PodcastEpisode::class, 'podcast_id')
    public function publishedEpisodes(): HasMany
    public function regions(): BelongsToMany
        return $this->belongsToMany(Region::class, 'podcast_region')
    public function followers(): MorphMany
        return $this->morphMany(Follow::class, 'followable');
    public function scopePublished($query)
    public function scopeByCategory($query, string $category)
    public function scopeForRegion($query, int $regionId)
        return $query->whereHas('regions', function ($q) use ($regionId) {
    public function incrementSubscribersCount(): void
    public function incrementEpisodesCount(): void
    public function incrementTotalListens(): void
    protected static function booted(): void
        self::creating(function (Podcast $podcast): void {
        self::created(function (Podcast $podcast): void {
    protected static function generateUniqueSlug(string $title): string
    protected function casts(): array
```

## PodcastEpisode
```php
    protected $fillable = [
    public function podcast(): BelongsTo
        return $this->belongsTo(Podcast::class, 'podcast_id');
    public function getAudioUrlAttribute(): string
    public function getFormattedDurationAttribute(): string
    public function scopePublished($query)
    public function incrementListensCount(): void
    public function incrementDownloadsCount(): void
    public function incrementLikesCount(): void
    public function incrementCommentsCount(): void
    protected static function booted(): void
        self::creating(function (PodcastEpisode $episode): void {
        self::created(function (PodcastEpisode $episode): void {
    protected static function generateUniqueSlug(string $title): string
    protected function casts(): array
```

## Product
```php
    protected $fillable = [
    public function store(): BelongsTo
        return $this->belongsTo(Store::class);
    public function orderItems(): HasMany
        return $this->hasMany(OrderItem::class);
    public function isInStock(): bool
    public function hasDiscount(): bool
    public function getDiscountPercentageAttribute(): ?float
    protected function casts(): array
```

## PromoCode
```php
    protected $fillable = [
    protected function casts(): array
    public function usages(): HasMany
        return $this->hasMany(PromoCodeUsage::class);
    public function scopeActive($query)
            ->where(function ($q) {
            ->where(function ($q) {
    public function scopeValid($query)
            ->where(function ($q) {
    public function isValid(): bool
    public function calculateDiscount(float $amount): float
    public static function generateUniqueCode(int $length = 8): string
```

## PromoCodeUsage
```php
    protected $fillable = [
    protected function casts(): array
    public function promoCode(): BelongsTo
        return $this->belongsTo(PromoCode::class);
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function ticketOrder(): BelongsTo
        return $this->belongsTo(TicketOrder::class);
```

## Rating
```php
    protected $fillable = [
    public function ratable(): MorphTo
        return $this->morphTo();
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function booking(): BelongsTo
        return $this->belongsTo(Booking::class);
    public function scopeByContext($query, string $context)
    public function scopeByType($query, string $type)
    public function scopeByRating($query, int $rating)
    public function scopeFromBookings($query)
    protected function casts(): array
```

## Region
```php
    protected $fillable = [
    public function parent(): BelongsTo
        return $this->belongsTo(self::class, 'parent_id');
    public function children(): HasMany
        return $this->hasMany(self::class, 'parent_id');
    public function zipcodes(): HasMany
        return $this->hasMany(RegionZipcode::class);
    public function newsArticles(): HasMany
        return $this->hasMany(NewsArticle::class);
    public function businesses(): BelongsToMany
        return $this->belongsToMany(Business::class, 'business_region')
    public function events(): BelongsToMany
        return $this->belongsToMany(Event::class, 'event_region')
    public function ancestors(): array
    public function descendants(): array
    public function hasZipcode(string $zipcode): bool
    public function getFullNameAttribute(): string
    public function scopeActive($query)
    public function scopeOfType($query, string $type)
    public function scopeForZipcode($query, string $zipcode)
        return $query->whereHas('zipcodes', function ($q) use ($zipcode) {
    public function scopeTopLevel($query)
    protected function casts(): array
```

## RegionZipcode
```php
    protected $fillable = [
    public function region(): BelongsTo
        return $this->belongsTo(Region::class);
    public function scopePrimary($query)
    public function scopeForZipcode($query, string $zipcode)
    protected function casts(): array
```

## Review
```php
    protected $fillable = [
    public function reviewable(): MorphTo
        return $this->morphTo();
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function approvedBy(): BelongsTo
        return $this->belongsTo(User::class, 'approved_by');
    public function markAsHelpful(int $userId): void
    public function removeHelpful(int $userId): void
    public function approve(int $approvedBy): void
    public function reject(string $reason): void
    public function scopeApproved($query)
    public function scopeByRating($query, int $rating)
    public function scopeFeatured($query)
    public function scopeVerified($query)
    protected function casts(): array
```

## Role
```php
    protected $fillable = [
    protected $appends = [
    public function memberships(): HasMany
        return $this->hasMany(WorkspaceMembership::class);
    public function getPermissionsAttribute(): array
```

## RssFeed
```php
    protected $fillable = [
    public function business(): BelongsTo
        return $this->belongsTo(Business::class);
    public function feedItems(): HasMany
        return $this->hasMany(RssFeedItem::class);
    public function dayNewsPosts(): HasMany
        return $this->hasMany(DayNewsPost::class);
    public function scopeActive($query)
    public function scopeInactive($query)
    public function scopeBroken($query)
    public function scopeHealthy($query)
    public function scopeDegraded($query)
    public function scopeUnhealthy($query)
    public function scopeByType($query, string $type)
    public function scopeAutoApproved($query)
    public function scopeNeedingCheck($query)
            ->where(function ($q) {
    public function isActive(): bool
    public function isHealthy(): bool
    public function isBroken(): bool
    public function markAsHealthy(): void
    public function markAsDegraded(?string $error = null): void
    public function markAsUnhealthy(?string $error = null): void
    public function markAsBroken(?string $error = null): void
    public function updateLastChecked(): void
    public function incrementItemCount(): void
    protected function casts(): array
```

## RssFeedItem
```php
    protected $fillable = [
    public function rssFeed(): BelongsTo
        return $this->belongsTo(RssFeed::class);
    public function dayNewsPosts(): HasMany
        return $this->hasMany(DayNewsPost::class);
    public function scopeProcessed($query)
    public function scopeUnprocessed($query)
    public function scopeRecent($query, int $days = 7)
    public function scopeByCategory($query, string $category)
    public function isProcessed(): bool
    public function markAsProcessed(): void
    public function markAsUnprocessed(): void
    protected function casts(): array
```

## SMBCrmCustomer
```php
    protected $fillable = [
    protected function casts(): array
    public function business(): BelongsTo
        return $this->belongsTo(Business::class);
    public function interactions(): HasMany
        return $this->hasMany(SMBCrmInteraction::class, 'customer_id');
    public function surveyResponses(): HasMany
        return $this->hasMany(BusinessSurveyResponse::class, 'customer_id');
```

## SMBCrmInteraction
```php
    protected $fillable = [
    protected function casts(): array
    public function business(): BelongsTo
        return $this->belongsTo(Business::class);
    public function customer(): BelongsTo
        return $this->belongsTo(SMBCrmCustomer::class, 'customer_id');
```

## SearchHistory
```php
    protected $fillable = [
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    protected function casts(): array
```

## SearchSuggestion
```php
    protected $fillable = [
    public function incrementPopularity(): void
    public function incrementClickCount(): void
    protected function casts(): array
```

## SmbBusiness
```php
    protected $fillable = [
    protected function casts(): array
    public function tenant(): BelongsTo
        return $this->belongsTo(Tenant::class);
    public function customers(): HasMany
        return $this->hasMany(Customer::class, 'smb_business_id');
    public function businessHours(): HasMany
        return $this->hasMany(BusinessHours::class);
    public function photos(): HasMany
        return $this->hasMany(BusinessPhoto::class);
    public function reviews(): HasMany
        return $this->hasMany(BusinessReview::class);
    public function attributes(): HasMany
        return $this->hasMany(BusinessAttribute::class);
```

## SocialAccount
```php
    protected $fillable = [
    protected $casts = [
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function getAvatarAttribute(): string
```

## SocialActivity
```php
    protected $fillable = [
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function actor(): BelongsTo
        return $this->belongsTo(User::class, 'actor_id');
    public function subject(): MorphTo
        return $this->morphTo();
    public function markAsRead(): void
    public function scopeUnread($query)
    public function scopeOfType($query, string $type)
    protected function casts(): array
```

## SocialCommentLike
```php
    protected $fillable = [
    public function comment(): BelongsTo
        return $this->belongsTo(SocialPostComment::class, 'comment_id');
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
```

## SocialFriendship
```php
    protected $fillable = [
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function friend(): BelongsTo
        return $this->belongsTo(User::class, 'friend_id');
    public function requester(): BelongsTo
        return $this->belongsTo(User::class, 'user_id');
    public function recipient(): BelongsTo
        return $this->belongsTo(User::class, 'friend_id');
    public function isPending(): bool
    public function isAccepted(): bool
    public function isBlocked(): bool
    protected function casts(): array
```

## SocialGroup
```php
    protected $fillable = [
    public function creator(): BelongsTo
        return $this->belongsTo(User::class, 'creator_id');
    public function members(): HasMany
        return $this->hasMany(SocialGroupMember::class, 'group_id');
    public function posts(): HasMany
        return $this->hasMany(SocialGroupPost::class, 'group_id');
    public function invitations(): HasMany
        return $this->hasMany(SocialGroupInvitation::class, 'group_id');
    public function approvedMembers(): HasMany
    public function admins(): HasMany
    public function membersCount(): int
    public function isPublic(): bool
    public function isPrivate(): bool
    public function isSecret(): bool
    protected function casts(): array
```

## SocialGroupInvitation
```php
    protected $fillable = [
    public function group(): BelongsTo
        return $this->belongsTo(SocialGroup::class, 'group_id');
    public function inviter(): BelongsTo
        return $this->belongsTo(User::class, 'inviter_id');
    public function invited(): BelongsTo
        return $this->belongsTo(User::class, 'invited_id');
    public function isPending(): bool
    public function isAccepted(): bool
    public function isDeclined(): bool
    public function isExpired(): bool
    public function scopePending($query)
    public function scopeNotExpired($query)
        return $query->where(function ($q) {
    protected function casts(): array
```

## SocialGroupMember
```php
    protected $fillable = [
    public function group(): BelongsTo
        return $this->belongsTo(SocialGroup::class, 'group_id');
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function isAdmin(): bool
    public function isModerator(): bool
    public function isMember(): bool
    public function isPending(): bool
    public function isApproved(): bool
    public function isBanned(): bool
    protected function casts(): array
```

## SocialGroupPost
```php
    protected $fillable = [
    public function group(): BelongsTo
        return $this->belongsTo(SocialGroup::class, 'group_id');
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function activities(): MorphMany
        return $this->morphMany(SocialActivity::class, 'subject');
    protected function casts(): array
```

## SocialPost
```php
    protected $fillable = [
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function likes(): HasMany
        return $this->hasMany(SocialPostLike::class, 'post_id');
    public function comments(): HasMany
        return $this->hasMany(SocialPostComment::class, 'post_id');
    public function shares(): HasMany
        return $this->hasMany(SocialPostShare::class, 'post_id');
    public function activities(): MorphMany
        return $this->morphMany(SocialActivity::class, 'subject');
    public function isLikedBy(User $user): bool
    public function likesCount(): int
    public function commentsCount(): int
    public function sharesCount(): int
    protected function casts(): array
```

## SocialPostComment
```php
    protected $fillable = [
    public function post(): BelongsTo
        return $this->belongsTo(SocialPost::class, 'post_id');
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function parent(): BelongsTo
        return $this->belongsTo(self::class, 'parent_id');
    public function replies(): HasMany
        return $this->hasMany(self::class, 'parent_id');
    public function likes(): HasMany
        return $this->hasMany(SocialCommentLike::class, 'comment_id');
    public function activities(): MorphMany
        return $this->morphMany(SocialActivity::class, 'subject');
    public function isLikedBy(User $user): bool
    public function likesCount(): int
    public function repliesCount(): int
    protected function casts(): array
```

## SocialPostLike
```php
    protected $fillable = [
    public function post(): BelongsTo
        return $this->belongsTo(SocialPost::class, 'post_id');
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
```

## SocialPostShare
```php
    protected $fillable = [
    public function post(): BelongsTo
        return $this->belongsTo(SocialPost::class, 'post_id');
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
```

## SocialUserFollow
```php
    protected $fillable = [
    public function follower(): BelongsTo
        return $this->belongsTo(User::class, 'follower_id');
    public function following(): BelongsTo
        return $this->belongsTo(User::class, 'following_id');
```

## SocialUserProfile
```php
    protected $fillable = [
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function isPublic(): bool
    public function isFriendsOnly(): bool
    public function isPrivate(): bool
    protected function casts(): array
```

## Store
```php
    protected $fillable = [
    public function getRouteKeyName(): string
    public function workspace(): BelongsTo
        return $this->belongsTo(Workspace::class);
    public function products(): HasMany
        return $this->hasMany(Product::class);
    public function orders(): HasMany
        return $this->hasMany(Order::class);
    public function isApproved(): bool
    public function isPending(): bool
    public function isRejected(): bool
    public function isSuspended(): bool
    public function canAcceptPayments(): bool
    protected function casts(): array
```

## Tag
```php
    protected $fillable = [
    public function posts(): BelongsToMany
        return $this->belongsToMany(DayNewsPost::class, 'day_news_post_tag')
    public function followers(): MorphMany
        return $this->morphMany(Follow::class, 'followable');
    public function scopeTrending($query)
    public function scopePopular($query)
    protected static function booted(): void
        self::creating(function (Tag $tag): void {
    protected static function generateUniqueSlug(string $name): string
    protected function casts(): array
```

## Task
```php
    protected $fillable = [
    protected function casts(): array
    public function tenant(): BelongsTo
        return $this->belongsTo(Tenant::class);
    public function customer(): BelongsTo
        return $this->belongsTo(Customer::class);
    public function assignedTo(): BelongsTo
        return $this->belongsTo(User::class, 'assigned_to_id');
    public function isCompleted(): bool
    public function isOverdue(): bool
```

## Tenant
```php
    protected $fillable = [
    protected function casts(): array
    public function users(): HasMany
        return $this->hasMany(User::class);
    public function smbBusinesses(): HasMany
        return $this->hasMany(SmbBusiness::class);
    public function customers(): HasMany
        return $this->hasMany(Customer::class);
    public function accountManagers(): HasMany
        return $this->hasMany(AccountManager::class);
    public function deals(): HasMany
        return $this->hasMany(Deal::class);
    public function interactions(): HasMany
        return $this->hasMany(Interaction::class);
    public function tasks(): HasMany
        return $this->hasMany(Task::class);
    public function campaigns(): HasMany
        return $this->hasMany(Campaign::class);
    public function isOnTrial(): bool
```

## TicketGift
```php
    protected $fillable = [
    protected function casts(): array
    public function ticketOrderItem(): BelongsTo
        return $this->belongsTo(TicketOrderItem::class);
    public function gifter(): BelongsTo
        return $this->belongsTo(User::class, 'gifter_id');
    public function recipient(): BelongsTo
        return $this->belongsTo(User::class, 'recipient_user_id');
    public function scopePending($query)
            ->where(function ($q) {
    public function scopeForGifter($query, string $userId)
    public function scopeForRecipient($query, string $email)
    public function redeem(string $userId): void
```

## TicketListing
```php
    protected $fillable = [
    protected function casts(): array
    public function ticketOrderItem(): BelongsTo
        return $this->belongsTo(TicketOrderItem::class);
    public function seller(): BelongsTo
        return $this->belongsTo(User::class, 'seller_id');
    public function buyer(): BelongsTo
        return $this->belongsTo(User::class, 'sold_to');
    public function event(): BelongsTo
        return $this->belongsTo(Event::class);
    public function scopeActive($query)
            ->where(function ($q) {
    public function scopeForEvent($query, string $eventId)
    public function markAsSold(string $buyerId): void
```

## TicketOrder
```php
    protected $fillable = [
    public function event(): BelongsTo
        return $this->belongsTo(Event::class);
    public function user(): BelongsTo
        return $this->belongsTo(User::class);
    public function items(): HasMany
        return $this->hasMany(TicketOrderItem::class);
    public function scopePending($query)
    public function scopeCompleted($query)
    public function scopeForUser($query, string $userId)
    public function scopeForEvent($query, string $eventId)
    public function getIsFreeOrderAttribute(): bool
    public function getFormattedTotalAttribute(): string
    public function getTotalQuantityAttribute(): int
    protected function casts(): array
```

## TicketOrderItem
```php
    protected $fillable = [
    public function ticketOrder(): BelongsTo
        return $this->belongsTo(TicketOrder::class);
    public function ticketPlan(): BelongsTo
        return $this->belongsTo(TicketPlan::class);
    protected function casts(): array
```

## TicketPlan
```php
    protected $fillable = [
    public function event(): BelongsTo
        return $this->belongsTo(Event::class);
    public function orderItems(): HasMany
        return $this->hasMany(TicketOrderItem::class);
    public function scopeActive($query)
    public function scopeAvailable($query)
    public function scopeForEvent($query, string $eventId)
    public function scopeOrderBySortOrder($query)
    public function getIsFreeAttribute(): bool
    public function getFormattedPriceAttribute(): string
    protected function casts(): array
```

## TicketTransfer
```php
    protected $fillable = [
    protected function casts(): array
    public function ticketOrderItem(): BelongsTo
        return $this->belongsTo(TicketOrderItem::class);
    public function fromUser(): BelongsTo
        return $this->belongsTo(User::class, 'from_user_id');
    public function toUser(): BelongsTo
        return $this->belongsTo(User::class, 'to_user_id');
    public function scopePending($query)
            ->where(function ($q) {
    public function scopeForUser($query, string $userId)
        return $query->where(function ($q) use ($userId) {
    public function complete(): void
```

## UpcomingShow
```php
    protected $fillable = [
    public function performer(): BelongsTo
        return $this->belongsTo(Performer::class);
    public function scopeUpcoming($query)
    public function scopeWithTickets($query)
    protected function casts(): array
```

## User
```php
    protected $fillable = [
    protected $hidden = [
    protected $appends = [
    public function socialAccounts(): HasMany
        return $this->hasMany(SocialAccount::class);
    public function getAvatarAttribute(): string
    public function workspaces(): HasMany
        return $this->hasMany(WorkspaceMembership::class);
    public function currentWorkspace(): BelongsTo
        return $this->belongsTo(Workspace::class, 'current_workspace_id');
    public function tenant(): BelongsTo
        return $this->belongsTo(Tenant::class);
    public function workspaceMemberships(): HasMany
        return $this->hasMany(WorkspaceMembership::class);
    public function isMemberOfWorkspace(?string $workspaceId): bool
    public function getMembershipForWorkspace(string $workspaceId): ?WorkspaceMembership
    public function hasSomePermissions(array $permissions, ?string $workspaceId): bool
    public function hasAllPermissions(array $permissions, ?string $workspaceId): bool
    public function isOwnerOfWorkspace(?string $workspaceId): bool
    public function socialPosts(): HasMany
        return $this->hasMany(SocialPost::class);
    public function authoredDayNewsPosts(): HasMany
        return $this->hasMany(DayNewsPost::class, 'author_id');
    public function socialProfile(): HasOne
        return $this->hasOne(SocialUserProfile::class);
    public function friendships(): HasMany
        return $this->hasMany(SocialFriendship::class);
    public function friendshipRequests(): HasMany
        return $this->hasMany(SocialFriendship::class, 'friend_id');
    public function followers(): HasMany
        return $this->hasMany(SocialUserFollow::class, 'following_id');
    public function following(): HasMany
        return $this->hasMany(SocialUserFollow::class, 'follower_id');
    public function socialGroups(): HasMany
        return $this->hasMany(SocialGroup::class, 'creator_id');
    public function groupMemberships(): HasMany
        return $this->hasMany(SocialGroupMember::class);
    public function groupInvitations(): HasMany
        return $this->hasMany(SocialGroupInvitation::class, 'invited_id');
    public function sentGroupInvitations(): HasMany
        return $this->hasMany(SocialGroupInvitation::class, 'inviter_id');
    public function socialActivities(): HasMany
        return $this->hasMany(SocialActivity::class);
    public function actorActivities(): HasMany
        return $this->hasMany(SocialActivity::class, 'actor_id');
    public function isFriendsWith(self $user): bool
    public function hasPendingFriendRequestWith(self $user): bool
    public function isFollowing(self $user): bool
    public function isMemberOfGroup(SocialGroup $group): bool
    public function unreadActivitiesCount(): int
```

## Venue
```php
    protected $fillable = [
    public function workspace(): BelongsTo
        return $this->belongsTo(Workspace::class);
    public function createdBy(): BelongsTo
        return $this->belongsTo(User::class, 'created_by');
    public function events(): HasMany
        return $this->hasMany(Event::class);
    public function bookings(): HasMany
        return $this->hasMany(Booking::class);
    public function follows(): MorphMany
        return $this->morphMany(Follow::class, 'followable');
    public function getLocationAttribute(): array
    public function getPricingAttribute(): array
    public function getDistanceAttribute(): float
    public function scopeActive($query)
    public function scopeVerified($query)
    public function scopeByType($query, string $type)
    public function scopeWithinRadius($query, float $lat, float $lng, float $radius)
    protected function casts(): array
```

## Workspace
```php
    protected $fillable = [
    public function getLogoAttribute($value)
    public function owner(): BelongsTo
        return $this->belongsTo(User::class, 'owner_id');
    public function members(): HasMany
        return $this->hasMany(WorkspaceMembership::class);
    public function invitations(): HasMany
        return $this->hasMany(WorkspaceInvitation::class);
    public function stores(): HasMany
        return $this->hasMany(Store::class);
    public function dayNewsPosts(): HasMany
        return $this->hasMany(DayNewsPost::class);
    public function canAcceptPayments(): bool
    protected function casts(): array
```

## WorkspaceInvitation
```php
    protected $fillable = [
    protected $casts = [
    public static function generateToken(): string
    public function workspace(): BelongsTo
        return $this->belongsTo(Workspace::class);
    public function inviter(): BelongsTo
        return $this->belongsTo(User::class, 'invited_by');
    public function isExpired(): bool
    public function isAccepted(): bool
    public function isValid(): bool
    public function markAsAccepted(): void
    public function scopePending($query)
    public function scopeExpired($query)
```

## WorkspaceMembership
```php
    protected $fillable = [
    protected $appends = [
    public function workspace()
        return $this->belongsTo(Workspace::class);
    public function user()
        return $this->belongsTo(User::class);
    public function role()
        return $this->belongsTo(Role::class);
    public function getPermissionsAttribute()
    public function isOwner()
    public function isAdmin()
    public function isMember()
```

## WriterAgent
```php
    protected $fillable = [
    public static function generateUniqueSlug(string $name): string
    public function regions(): BelongsToMany
        return $this->belongsToMany(Region::class, 'writer_agent_region')
    public function posts(): HasMany
        return $this->hasMany(DayNewsPost::class);
    public function getPrimaryRegionAttribute(): ?Region
    public function getAvatarUrlAttribute(): string
    public function getSystemPromptAttribute(): ?string
    public function getStyleInstructionsAttribute(): ?string
    public function handlesCategory(array|string $categories): bool
    public function coversRegion(string $regionId): bool
    public function scopeActive($query)
    public function scopeForRegion($query, string $regionId)
        return $query->whereHas('regions', function ($q) use ($regionId) {
    public function scopeForCategory($query, string $category)
    public function scopeByWritingStyle($query, string $style)
    protected static function booted(): void
        self::creating(function (WriterAgent $agent): void {
    protected function casts(): array
```

