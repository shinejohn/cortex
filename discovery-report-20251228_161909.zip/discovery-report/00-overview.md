# Laravel Project Discovery Report
Generated: Sun Dec 28 16:19:13 EST 2025
Project: /Users/johnshine/Dropbox/Fibonacco/Day-News/Multisite

## Quick Stats

| Metric | Count |
|--------|-------|
| Models | 142 |
| Controllers | 102 |
| Migrations | 123 |
| Routes (web) | 229 |
| Routes (api) | 20 |
| Services | 82 |
| Jobs | 27 |
| Form Requests | 33 |
| API Resources | 0 |
| Policies | 20 |

## Composer Dependencies (relevant)
```
    "name": "laravel/react-starter-kit",
        "laravel",
        "cesargb/laravel-magiclink": "^2.24.1",
        "climactic/laravel-credits": "^1.4.0",
        "inertiajs/inertia-laravel": "^2.0.16",
        "laravel/framework": "^12.43.1",
        "laravel/horizon": "^5.41.0",
        "laravel/nightwatch": "^1.21.1",
        "laravel/socialite": "^5.24.0",
        "laravel/tinker": "^2.10.2",
        "sentry/sentry-laravel": "^4.20.0",
        "spatie/laravel-sitemap": "^7.3.8",
        "laravel/boost": "^1.8.5",
        "laravel/pail": "^1.2.4",
        "laravel/pint": "^1.26.0",
        "laravel/sail": "^1.51.0",
        "pestphp/pest-plugin-laravel": "^4.0.0"
            "@php artisan vendor:publish --tag=laravel-assets --ansi --force"
            "bunx concurrently -c \"#93c5fd,#c4b5fd,#fb7185,#fdba74,#f97316\" \"php artisan serve\" \"php artisan horizon\" \"php artisan pail --timeout=0\" \"php artisan inertia:start-ssr\" --names=server,horizon,logs,ssr"
        "laravel": {
```

## Directory Structure
```
app
app/Dto
app/Dto/Workspace
app/Traits
app/Mail
app/Contracts
app/Providers
app/Providers/Filament
app/Models
app/Policies
app/Filament
app/Filament/Forms
app/Filament/Forms/Components
app/Filament/Resources
app/Filament/Resources/TicketOrders
app/Filament/Resources/TicketOrders/Tables
app/Filament/Resources/TicketOrders/Schemas
app/Filament/Resources/TicketOrders/Pages
app/Filament/Resources/Calendars
app/Filament/Resources/Calendars/Tables
app/Filament/Resources/Calendars/Schemas
app/Filament/Resources/Calendars/Pages
app/Filament/Resources/Regions
app/Filament/Resources/Regions/Tables
app/Filament/Resources/Regions/Schemas
app/Filament/Resources/Regions/Pages
app/Filament/Resources/Businesses
app/Filament/Resources/Businesses/Tables
app/Filament/Resources/Businesses/Schemas
app/Filament/Resources/Businesses/Pages
app/Filament/Resources/DayNewsPosts
app/Filament/Resources/DayNewsPosts/Tables
app/Filament/Resources/DayNewsPosts/Schemas
app/Filament/Resources/DayNewsPosts/Pages
app/Filament/Resources/Products
app/Filament/Resources/Products/Tables
app/Filament/Resources/Products/Schemas
app/Filament/Resources/Products/Pages
app/Filament/Resources/Bookings
app/Filament/Resources/Bookings/Tables
```
