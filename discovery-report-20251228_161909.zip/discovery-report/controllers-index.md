# Controllers Index

## Admin/Advertising/CampaignController.php

**Methods:**
    - __construct
    - index
    - create
    - store
    - show
    - edit
    - update
    - updateStatus

## Admin/Advertising/CreativeController.php

**Methods:**
    - index
    - create
    - store
    - show
    - edit
    - update
    - updateStatus

## Admin/Advertising/PlacementController.php

**Methods:**
    - index
    - create
    - store
    - show
    - edit
    - update

## Admin/Advertising/ReportController.php

**Methods:**
    - __construct
    - index
    - campaign

## Admin/Email/CampaignController.php

**Methods:**
    - __construct
    - index
    - show
    - generateDigest
    - generateNewsletter

## Admin/Email/SubscriberController.php

**Methods:**
    - index
    - show

## Admin/Email/TemplateController.php

**Methods:**
    - index
    - create
    - store
    - show
    - edit
    - update

## Admin/Emergency/AlertController.php

**Methods:**
    - __construct
    - index
    - create
    - store
    - show
    - publish
    - cancel

## Ads/AdController.php

**Methods:**
    - __construct
    - serve
    - click

## AlphaSite/BusinessPageController.php

**Methods:**
    - __construct
    - showBySubdomain
    - show
    - showTab
    - reviews
    - photos
    - menu
    - articles
    - events
    - coupons
    - achievements
    - aiChat

## AlphaSite/ClaimController.php

**Methods:**
    - __construct
    - start
    - verify
    - complete
    - subscribe

## AlphaSite/CommunityController.php

**Methods:**
    - __construct
    - show
    - downtown
    - category

## AlphaSite/DirectoryController.php

**Methods:**
    - __construct
    - home
    - index
    - byLocation
    - getStarted

## AlphaSite/IndustryController.php

**Methods:**
    - __construct
    - index
    - show
    - byLocation

## AlphaSite/SMBCrmController.php

**Methods:**
    - __construct
    - dashboard
    - customers
    - showCustomer
    - interactions
    - faqs
    - storeFaq
    - surveys
    - aiServices

## AlphaSite/SearchController.php

**Methods:**
    - __construct
    - index
    - suggestions

## Api/AdvertisementController.php

**Methods:**
    - __construct
    - index
    - trackImpression
    - trackClick

## Api/LocationController.php

**Methods:**
    - __construct
    - detectFromBrowser
    - setRegion
    - search
    - clear

## Api/N8nIntegrationController.php

**Methods:**
    - getRegions
    - upsertBusiness
    - getBusinessFeeds
    - upsertFeed
    - getAllFeeds
    - updateFeedHealth
    - publishArticle
    - updateArticleStatus

## Api/NotificationController.php

**Methods:**
    - __construct
    - getVapidKey
    - registerWebPush
    - requestPhoneVerification
    - verifyPhoneAndSubscribe
    - updatePreferences
    - unsubscribe
    - getSubscriptions

## Auth/AuthenticatedSessionController.php

**Methods:**
    - __construct
    - create
    - createMagicLink
    - store
    - destroy
    - generateMagicLink
    - magicLinkCallback

## Auth/ConfirmablePasswordController.php

**Methods:**
    - show
    - store

## Auth/EmailVerificationNotificationController.php

**Methods:**
    - store

## Auth/EmailVerificationPromptController.php

**Methods:**
    - __invoke

## Auth/NewPasswordController.php

**Methods:**
    - create
    - store

## Auth/PasswordResetLinkController.php

**Methods:**
    - create
    - store

## Auth/RegisteredUserController.php

**Methods:**
    - create
    - store

## Auth/SocialiteController.php

**Methods:**
    - __construct
    - redirect
    - callback

## Auth/VerifyEmailController.php

**Methods:**
    - __invoke

## BookingController.php

**Methods:**
    - index
    - show
    - create
    - store
    - edit
    - update
    - confirm
    - cancel
    - destroy

## CalendarController.php

**Methods:**
    - publicIndex

## CartController.php

**Methods:**
    - index
    - add
    - update
    - remove
    - clear
    - count
    - items

## CheckInController.php

**Methods:**
    - index
    - store
    - show
    - destroy
    - forEvent

## CommunityController.php

**Methods:**
    - index
    - show
    - createThread
    - storeThread
    - showThread
    - storeReply
    - updateReply
    - destroyReply
    - likeReply

## Controller.php

**Methods:**

## CrossDomainAuthController.php

**Methods:**
    - __construct
    - sync
    - logoutSync

## DayNews/AnnouncementController.php

**Methods:**
    - index
    - create
    - store
    - show
    - edit
    - update
    - destroy

## DayNews/ArchiveController.php

**Methods:**
    - __construct
    - index
    - calendar

## DayNews/ArticleCommentController.php

**Methods:**
    - index
    - store
    - update
    - destroy
    - toggleLike
    - report
    - togglePin
    - moderate

## DayNews/AuthorController.php

**Methods:**
    - __construct
    - index
    - show
    - create
    - store

## DayNews/BusinessController.php

**Methods:**
    - __construct
    - index
    - show

## DayNews/ClassifiedController.php

**Methods:**
    - __construct
    - index
    - create
    - store
    - selectRegions
    - storeRegions
    - selectTimeframe
    - storeTimeframe
    - show
    - paymentSuccess
    - paymentCancel
    - confirmation

## DayNews/CouponController.php

**Methods:**
    - __construct
    - index
    - create
    - store
    - show
    - use
    - edit
    - update
    - destroy

## DayNews/CreatorController.php

**Methods:**
    - __construct
    - index
    - create
    - store
    - dashboard

## DayNews/EventController.php

**Methods:**
    - __construct
    - index
    - show

## DayNews/LegalNoticeController.php

**Methods:**
    - index
    - create
    - store
    - show

## DayNews/MemorialController.php

**Methods:**
    - index
    - create
    - store
    - show

## DayNews/PhotoController.php

**Methods:**
    - __construct
    - index
    - create
    - store
    - show
    - destroy
    - albums
    - showAlbum
    - createAlbum
    - storeAlbum

## DayNews/PodcastController.php

**Methods:**
    - __construct
    - show
    - create
    - store
    - createEpisode
    - storeEpisode
    - showEpisode
    - publishEpisode

## DayNews/PostController.php

**Methods:**
    - __construct
    - index
    - create
    - store
    - edit
    - update
    - destroy

## DayNews/PostPaymentController.php

**Methods:**
    - __construct
    - success
    - cancel

## DayNews/PostPublishController.php

**Methods:**
    - __construct
    - show
    - store

## DayNews/PublicPostController.php

**Methods:**
    - __construct
    - show

## DayNews/RegionHomeController.php

**Methods:**
    - __construct
    - show

## DayNews/SearchController.php

**Methods:**
    - __construct
    - index
    - suggestions

## DayNews/SitemapController.php

**Methods:**
    - robots
    - index
    - posts
    - static
    - regions

## DayNews/TagController.php

**Methods:**
    - __construct
    - show

## DayNews/TrendingController.php

**Methods:**
    - __construct
    - index

## DowntownGuide/AchievementController.php

**Methods:**
    - __construct
    - index
    - leaderboard

## DowntownGuide/BusinessController.php

**Methods:**
    - __construct
    - index
    - show

## DowntownGuide/CouponController.php

**Methods:**
    - __construct
    - index
    - show
    - apply

## DowntownGuide/ProfileController.php

**Methods:**
    - __construct
    - show
    - me
    - update

## DowntownGuide/ReviewController.php

**Methods:**
    - __construct
    - index
    - create
    - store
    - helpful

## DowntownGuide/SearchController.php

**Methods:**
    - __construct
    - index
    - suggestions

## DowntownGuide/SitemapController.php

**Methods:**
    - robots
    - index

## Email/TrackingController.php

**Methods:**
    - __construct
    - trackOpen
    - trackClick
    - unsubscribe
    - processUnsubscribe
    - preferences
    - updatePreferences

## EngagementController.php

**Methods:**
    - __construct
    - track
    - sessionStart
    - sessionEnd

## EventCity/BusinessController.php

**Methods:**
    - __construct
    - index
    - show

## EventCity/SitemapController.php

**Methods:**
    - robots
    - index
    - events
    - venues
    - performers
    - calendars
    - community
    - static

## EventController.php

**Methods:**
    - __construct
    - publicIndex
    - index
    - show
    - featured
    - upcoming
    - create
    - store
    - edit
    - update
    - destroy

## FollowController.php

**Methods:**
    - toggle
    - checkStatus

## HomePageController.php

**Methods:**
    - __construct
    - index

## HubAnalyticsController.php

**Methods:**
    - index
    - trackPageView
    - trackVisitor
    - getStats

## HubBuilderController.php

**Methods:**
    - show
    - updateDesign
    - updateSections
    - deleteSection
    - preview
    - publish

## HubController.php

**Methods:**
    - index
    - create
    - store
    - show
    - edit
    - update
    - destroy

## NotificationController.php

**Methods:**
    - index
    - getUnread
    - markAsRead
    - markAllAsRead

## OrderController.php

**Methods:**
    - __construct
    - index
    - show
    - checkout
    - success
    - cancel
    - updateStatus

## OrganizationController.php

**Methods:**
    - __construct
    - getContent
    - relate
    - search
    - hierarchy

## OrganizationRelationshipController.php

**Methods:**
    - store
    - update
    - destroy
    - bulkStore

## PerformerController.php

**Methods:**
    - publicIndex
    - index
    - show
    - featured
    - trending
    - create
    - store
    - edit
    - update
    - destroy

## ProductController.php

**Methods:**
    - __construct
    - discover
    - create
    - store
    - show
    - edit
    - update
    - destroy

## PromoCodeController.php

**Methods:**
    - index
    - create
    - store
    - show
    - edit
    - update
    - destroy
    - validate

## Settings/BillingController.php

**Methods:**
    - __construct
    - show
    - connectStripe
    - stripeReturn
    - stripeRefresh
    - stripeDashboard

## Settings/PasswordController.php

**Methods:**
    - edit
    - update

## Settings/ProfileController.php

**Methods:**
    - edit
    - update
    - destroy

## Settings/WorkspaceSettingsController.php

**Methods:**
    - showOverview
    - showMembers
    - update
    - inviteUser
    - updateMemberRole
    - removeMember
    - cancelInvitation

## Social/ImageUploadController.php

**Methods:**
    - upload

## SocialController.php

**Methods:**
    - index
    - createPost
    - likePost
    - unlikePost
    - createComment
    - deleteComment
    - sendFriendRequest
    - acceptFriendRequest
    - profile
    - updateProfile
    - activities
    - markActivitiesAsRead
    - friendsIndex
    - declineFriendRequest
    - cancelFriendRequest
    - removeFriend

## SocialFeedController.php

**Methods:**
    - __construct
    - index
    - forYou
    - followed

## SocialGroupController.php

**Methods:**
    - index
    - create
    - store
    - show
    - join
    - leave
    - invite
    - respondToInvitation
    - searchUsers

## SocialGroupPostController.php

**Methods:**
    - index
    - store
    - show
    - update
    - destroy
    - pin

## SocialMessageController.php

**Methods:**
    - index
    - show
    - sendMessage
    - newMessage
    - startConversation

## StoreController.php

**Methods:**
    - __construct
    - index
    - myStores
    - create
    - store
    - show
    - edit
    - update
    - connectStripe
    - connectReturn
    - connectRefresh
    - stripeDashboard

## StripeWebhookController.php

**Methods:**
    - __invoke

## TicketGiftController.php

**Methods:**
    - create
    - store
    - redeem
    - complete
    - cancel

## TicketMarketplaceController.php

**Methods:**
    - index
    - create
    - store
    - show
    - purchase
    - destroy

## TicketOrderController.php

**Methods:**
    - __construct
    - index
    - store
    - show
    - update
    - destroy
    - checkoutSuccess
    - checkoutCancel

## TicketPageController.php

**Methods:**
    - index
    - selection
    - myTickets
    - verifyTicket

## TicketPlanController.php

**Methods:**
    - index
    - store
    - show
    - update
    - destroy
    - forEvent

## TicketTransferController.php

**Methods:**
    - create
    - store
    - accept
    - complete
    - cancel

## VenueController.php

**Methods:**
    - publicIndex
    - index
    - show
    - featured
    - create
    - store
    - edit
    - update
    - destroy

## WorkspaceController.php

**Methods:**
    - store
    - switch
    - showInvitation
    - acceptInvitationForLoggedInUser
    - acceptInvitationByToken

